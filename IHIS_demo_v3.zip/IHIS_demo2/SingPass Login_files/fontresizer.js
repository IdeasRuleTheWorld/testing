/**
 * Create a cookie with the given name and value and other optional parameters.
 *
 * @example $.cookie('the_cookie', 'the_value');
 * @desc Set the value of a cookie.
 * @example $.cookie('the_cookie', 'the_value', { expires: 7, path: '/', domain: 'jquery.com', secure: true });
 * @desc Create a cookie with all available options.
 * @example $.cookie('the_cookie', 'the_value');
 * @desc Create a session cookie.
 * @example $.cookie('the_cookie', null);
 * @desc Delete a cookie by passing null as value. Keep in mind that you have to use the same path and domain
 *       used when the cookie was set.
 *
 * @param String name The name of the cookie.
 * @param String value The value of the cookie.
 * @param Object options An object literal containing key/value pairs to provide optional cookie attributes.
 * @option Number|Date expires Either an integer specifying the expiration date from now on in days or a Date object.
 *                             If a negative value is specified (e.g. a date in the past), the cookie will be deleted.
 *                             If set to null or omitted, the cookie will be a session cookie and will not be retained
 *                             when the the browser exits.
 * @option String path The value of the path atribute of the cookie (default: path of page that created the cookie).
 * @option String domain The value of the domain attribute of the cookie (default: domain of page that created the cookie).
 * @option Boolean secure If true, the secure attribute of the cookie will be set and the cookie transmission will
 *                        require a secure protocol (like HTTPS).
 * @type undefined
 *
 * @name $.cookie
 * @cat Plugins/Cookie
 * @author Klaus Hartl/klaus.hartl@stilbuero.de
 */

/**
 * Get the value of a cookie with the given name.
 *
 * @example $.cookie('the_cookie');
 * @desc Get the value of a cookie.
 *
 * @param String name The name of the cookie.
 * @return The value of the cookie.
 * @type String
 *
 * @name $.cookie
 * @cat Plugins/Cookie
 * @author Klaus Hartl/klaus.hartl@stilbuero.de
 */
jQuery.cookie = function(name, value, options) {
    if (typeof value != 'undefined') { // name and value given, set cookie
        options = options || {};
        if (value === null) {
            value = '';
            options.expires = -1;
        }
        var expires = '';
        if (options.expires && (typeof options.expires == 'number' || options.expires.toUTCString)) {
            var date;
            if (typeof options.expires == 'number') {
                date = new Date();
                date.setTime(date.getTime() + (options.expires * 24 * 60 * 60 * 1000));
            } else {
                date = options.expires;
            }
            expires = '; expires=' + date.toUTCString(); // use expires attribute, max-age is not supported by IE
        }
        // CAUTION: Needed to parenthesize options.path and options.domain
        // in the following expressions, otherwise they evaluate to undefined
        // in the packed version for some reason...
        var path = options.path ? '; path=' + (options.path) : '';
        var domain = options.domain ? '; domain=' + (options.domain) : '';
        var secure = options.secure ? '; secure' : '';
        document.cookie = [name, '=', encodeURIComponent(value), expires, path, domain, secure].join('');
    } else { // only name given, get cookie
        var cookieValue = null;
        if (document.cookie && document.cookie != '') {
            var cookies = document.cookie.split(';');
            for (var i = 0; i < cookies.length; i++) {
                var cookie = jQuery.trim(cookies[i]);
                // Does this cookie string begin with the name we want?
                if (cookie.substring(0, name.length + 1) == (name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        return cookieValue;
    }
};

/**
 * Fontsizer Plugin
 */
(function($) {
    var getElementTextContent = function(elmnt) {
        var result = "";
        try {
            result = elmnt.contents().filter(function(){
                return this.nodeType == 3; 
            })[0].nodeValue;
        } catch (err) {
            // do nothing
        }
        return result;
    };

    $.fn.fontscale = function(selectors, adjustment) {

        // If cookie is enable
        if ($.isFunction($.cookie)) {

            var cookieSetting = {delta:0, unit:"px"};
            if ($.cookie("fontscale")) {
                cookieSetting = $.fn.fontscale.readcookie('fontscale');
            } else {
                $.fn.fontscale.updatecookie("save", cookieSetting);
            }

            this.each(function() {
                $.fn.fontscale.scale(selectors, adjustment, cookieSetting);
            });
            return this;
        }
    };

    $.fn.fontscale.scale = function(selectors, adjustment, settings) {

        // for loading page
        if (adjustment === null) {
            $(selectors).each(function() {
                if (getElementTextContent($(this)).length) {
                    var currentSize = parseInt($(this).css("font-size"));
                    var currentLeading = parseInt($(this).css("line-height"));
                    $(this).css("font-size", currentSize + parseInt(settings.delta));
                    if (settings.adjustLeading) $(this).css("line-height", currentLeading + changeValue);
                }
            });
            return;
        }

        var changeValue = 0;
        if (adjustment == "+" || adjustment == "up") {
            if (settings.delta < 3) {
                settings.delta = parseInt(settings.delta) + 1;
                changeValue = 1;
            }
        } else if (adjustment == "-" || adjustment == "down") {
            if (settings.delta > -3) {
                settings.delta = parseInt(settings.delta) - 1;
                changeValue = -1;
            }
        } else if (adjustment == "reset") {
            return $.fn.fontscale.reset(selectors, settings);
        }

        if (settings.delta < 4 && settings.delta > -4) {
            $(selectors).each(function() {
                if (getElementTextContent($(this)).length) {
                    var currentSize = parseInt($(this).css("font-size"));
                    var currentLeading = parseInt($(this).css("line-height"));
                    $(this).css("font-size", currentSize + changeValue);
                    if (settings.adjustLeading) $(this).css("line-height", currentLeading + changeValue);
                }
            });

            $.fn.fontscale.updatecookie("save", settings);
        }
        return;
    };

    $.fn.fontscale.reset = function(object, settings) {

        // remove any scaling done inline (assumed to be from this plugin)
        $(object).each(function(i) {
            $(this).css("font-size", "");
            if (settings.adjustLeading) $(this).css('line-height','');
        });

        $.fn.fontscale.updatecookie("delete", settings);
    }

    $.fn.fontscale.updatecookie = function(action, settings) {

        // delete the cookie if we're performing a reset, do nothing else
        if (action == "delete") {
            $.cookie("fontscale", null, {path:"/", expires:30});
            return true;
        } else if (action == "save") {
            $.cookie("fontscale", "delta="+settings.delta+"&unit="+settings.unit, {path:"/", expires:30});
        }
    };

    $.fn.fontscale.readcookie = function(cookieName) {

        var val_string = $.cookie(cookieName);
        var objResult = {};
        $.each(val_string.split("&"), function() {
            var prm=this.split("=");
            objResult[prm[0]] = prm[1];
        });
        return objResult;
    };

})(jQuery);

function initFontSizer(selectors) {

    if ($.isFunction($.cookie)) {
        $("#font-default").click(function (e) {
            $("#font-default").fontscale(selectors, "reset");
        });

        $("#font-large").click(function (e) {
            $("#font-large").fontscale(selectors, "up");
        });

        $("#font-small").click(function (e) {
            $("#font-small").fontscale(selectors, "down");
        });

        var cookieSetting = {delta:0, unit:"px"};
        if ($.cookie("fontscale")) {
            cookieSetting = $.fn.fontscale.readcookie('fontscale');
            $.fn.fontscale.scale(selectors, null, cookieSetting);
        }
    }
}

$(document).ready(function() {

    initFontSizer("body");
});