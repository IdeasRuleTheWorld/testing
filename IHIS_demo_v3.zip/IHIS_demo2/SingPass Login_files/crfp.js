function cs_get_domain(SITE_ID) {
	if (SITE_ID == "78c6718e6ccb6e93ecf465ee043986dac6895154") {
		return "vg.csftr.com";
	} else {
		return "vg2.csftr.com";
	}
}

function cs_el_e(m) {
    var qstring = getParams("crfp.js");
    var SITE_ID = qstring.SITE_ID;
    var SESSION_ID = qstring.SESSION_ID;
    var CS_DOM = cs_get_domain(SITE_ID);

    if (SITE_ID == "2be9773fa33efea8f522daaf801f6e94fb501989") {
        var xhttp;
        if (window.XMLHttpRequest) { xhttp = new XMLHttpRequest(); } 
        else if (window.XDomainRequest) { xhttp = new XDomainRequest(); }
        else { xhttp = new ActiveXObject("Microsoft.XMLHTTP"); }

        var url = window.location.protocol+'//'+CS_DOM+'/vanguard/fp_e.php';
        // var url = window.location.protocol+'//cashshielddev.cashrun.com/fanshi/crfp-test/fp_e.php';
        var params = ('SESSION_ID='+SESSION_ID+'&SITE_ID='+SITE_ID+'&M='+m.message+'&L='+m.lineNumber+'&S='+encodeURIComponent(m.stack));
        xhttp.open("POST", url, true);
        xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xhttp.send(params);
    }
}

function cs_el_det(){
    try {
        var qstring = getParams("crfp.js");
        var SITE_ID = qstring.SITE_ID;
        var SESSION_ID = qstring.SESSION_ID;
        var CS_DOM = cs_get_domain(SITE_ID);

        if (SITE_ID == "2be9773fa33efea8f522daaf801f6e94fb501989") {
            var xhttp;
            if (window.XMLHttpRequest) { 
            	xhttp = new XMLHttpRequest(); 
            } else if (window.XDomainRequest) { 
            	xhttp = new XDomainRequest(); 
            } else { 
            	xhttp = new ActiveXObject("Microsoft.XMLHTTP"); 
            }

            var url = window.location.protocol+'//'+CS_DOM+'/vanguard/fp_det.php?SESSION_ID='+SESSION_ID+'&SITE_ID='+SITE_ID+'&B='+navigator.userAgent;
            xhttp.open("GET", url, true);
            xhttp.send();
        }
    } catch (e) {
        cs_el_e(e);
    }
}

cs_el_det();

try {
    var SEP   = '|';
    ua    = window.navigator.userAgent.toLowerCase();
    opera = ua.indexOf( "opera" ) >= 0;
    ie    = ua.indexOf( "msie" ) >= 0 && !opera;
    iemac = ie && ua.indexOf( "mac" ) >= 0;
    moz   = ua.indexOf( "mozilla" ) && !ie && !opera;
    os    = window.navigator.platform;
} catch (e) {
    // Probably IE 6
}


/*
CryptoJS v3.1.2
code.google.com/p/crypto-js
(c) 2009-2013 by Jeff Mott. All rights reserved.
code.google.com/p/crypto-js/wiki/License
*/
var CryptoJS=CryptoJS||function(s,p){var m={},l=m.lib={},n=function(){},r=l.Base={extend:function(b){n.prototype=this;var h=new n;b&&h.mixIn(b);h.hasOwnProperty("init")||(h.init=function(){h.$super.init.apply(this,arguments)});h.init.prototype=h;h.$super=this;return h},create:function(){var b=this.extend();b.init.apply(b,arguments);return b},init:function(){},mixIn:function(b){for(var h in b)b.hasOwnProperty(h)&&(this[h]=b[h]);b.hasOwnProperty("toString")&&(this.toString=b.toString)},clone:function(){return this.init.prototype.extend(this)}},
q=l.WordArray=r.extend({init:function(b,h){b=this.words=b||[];this.sigBytes=h!=p?h:4*b.length},toString:function(b){return(b||t).stringify(this)},concat:function(b){var h=this.words,a=b.words,j=this.sigBytes;b=b.sigBytes;this.clamp();if(j%4)for(var g=0;g<b;g++)h[j+g>>>2]|=(a[g>>>2]>>>24-8*(g%4)&255)<<24-8*((j+g)%4);else if(65535<a.length)for(g=0;g<b;g+=4)h[j+g>>>2]=a[g>>>2];else h.push.apply(h,a);this.sigBytes+=b;return this},clamp:function(){var b=this.words,h=this.sigBytes;b[h>>>2]&=4294967295<<
32-8*(h%4);b.length=s.ceil(h/4)},clone:function(){var b=r.clone.call(this);b.words=this.words.slice(0);return b},random:function(b){for(var h=[],a=0;a<b;a+=4)h.push(4294967296*s.random()|0);return new q.init(h,b)}}),v=m.enc={},t=v.Hex={stringify:function(b){var a=b.words;b=b.sigBytes;for(var g=[],j=0;j<b;j++){var k=a[j>>>2]>>>24-8*(j%4)&255;g.push((k>>>4).toString(16));g.push((k&15).toString(16))}return g.join("")},parse:function(b){for(var a=b.length,g=[],j=0;j<a;j+=2)g[j>>>3]|=parseInt(b.substr(j,
2),16)<<24-4*(j%8);return new q.init(g,a/2)}},a=v.Latin1={stringify:function(b){var a=b.words;b=b.sigBytes;for(var g=[],j=0;j<b;j++)g.push(String.fromCharCode(a[j>>>2]>>>24-8*(j%4)&255));return g.join("")},parse:function(b){for(var a=b.length,g=[],j=0;j<a;j++)g[j>>>2]|=(b.charCodeAt(j)&255)<<24-8*(j%4);return new q.init(g,a)}},u=v.Utf8={stringify:function(b){try{return decodeURIComponent(escape(a.stringify(b)))}catch(g){throw Error("Malformed UTF-8 data");}},parse:function(b){return a.parse(unescape(encodeURIComponent(b)))}},
g=l.BufferedBlockAlgorithm=r.extend({reset:function(){this._data=new q.init;this._nDataBytes=0},_append:function(b){"string"==typeof b&&(b=u.parse(b));this._data.concat(b);this._nDataBytes+=b.sigBytes},_process:function(b){var a=this._data,g=a.words,j=a.sigBytes,k=this.blockSize,m=j/(4*k),m=b?s.ceil(m):s.max((m|0)-this._minBufferSize,0);b=m*k;j=s.min(4*b,j);if(b){for(var l=0;l<b;l+=k)this._doProcessBlock(g,l);l=g.splice(0,b);a.sigBytes-=j}return new q.init(l,j)},clone:function(){var b=r.clone.call(this);
b._data=this._data.clone();return b},_minBufferSize:0});l.Hasher=g.extend({cfg:r.extend(),init:function(b){this.cfg=this.cfg.extend(b);this.reset()},reset:function(){g.reset.call(this);this._doReset()},update:function(b){this._append(b);this._process();return this},finalize:function(b){b&&this._append(b);return this._doFinalize()},blockSize:16,_createHelper:function(b){return function(a,g){return(new b.init(g)).finalize(a)}},_createHmacHelper:function(b){return function(a,g){return(new k.HMAC.init(b,
g)).finalize(a)}}});var k=m.algo={};return m}(Math);
(function(s){function p(a,k,b,h,l,j,m){a=a+(k&b|~k&h)+l+m;return(a<<j|a>>>32-j)+k}function m(a,k,b,h,l,j,m){a=a+(k&h|b&~h)+l+m;return(a<<j|a>>>32-j)+k}function l(a,k,b,h,l,j,m){a=a+(k^b^h)+l+m;return(a<<j|a>>>32-j)+k}function n(a,k,b,h,l,j,m){a=a+(b^(k|~h))+l+m;return(a<<j|a>>>32-j)+k}for(var r=CryptoJS,q=r.lib,v=q.WordArray,t=q.Hasher,q=r.algo,a=[],u=0;64>u;u++)a[u]=4294967296*s.abs(s.sin(u+1))|0;q=q.MD5=t.extend({_doReset:function(){this._hash=new v.init([1732584193,4023233417,2562383102,271733878])},
_doProcessBlock:function(g,k){for(var b=0;16>b;b++){var h=k+b,w=g[h];g[h]=(w<<8|w>>>24)&16711935|(w<<24|w>>>8)&4278255360}var b=this._hash.words,h=g[k+0],w=g[k+1],j=g[k+2],q=g[k+3],r=g[k+4],s=g[k+5],t=g[k+6],u=g[k+7],v=g[k+8],x=g[k+9],y=g[k+10],z=g[k+11],A=g[k+12],B=g[k+13],C=g[k+14],D=g[k+15],c=b[0],d=b[1],e=b[2],f=b[3],c=p(c,d,e,f,h,7,a[0]),f=p(f,c,d,e,w,12,a[1]),e=p(e,f,c,d,j,17,a[2]),d=p(d,e,f,c,q,22,a[3]),c=p(c,d,e,f,r,7,a[4]),f=p(f,c,d,e,s,12,a[5]),e=p(e,f,c,d,t,17,a[6]),d=p(d,e,f,c,u,22,a[7]),
c=p(c,d,e,f,v,7,a[8]),f=p(f,c,d,e,x,12,a[9]),e=p(e,f,c,d,y,17,a[10]),d=p(d,e,f,c,z,22,a[11]),c=p(c,d,e,f,A,7,a[12]),f=p(f,c,d,e,B,12,a[13]),e=p(e,f,c,d,C,17,a[14]),d=p(d,e,f,c,D,22,a[15]),c=m(c,d,e,f,w,5,a[16]),f=m(f,c,d,e,t,9,a[17]),e=m(e,f,c,d,z,14,a[18]),d=m(d,e,f,c,h,20,a[19]),c=m(c,d,e,f,s,5,a[20]),f=m(f,c,d,e,y,9,a[21]),e=m(e,f,c,d,D,14,a[22]),d=m(d,e,f,c,r,20,a[23]),c=m(c,d,e,f,x,5,a[24]),f=m(f,c,d,e,C,9,a[25]),e=m(e,f,c,d,q,14,a[26]),d=m(d,e,f,c,v,20,a[27]),c=m(c,d,e,f,B,5,a[28]),f=m(f,c,
d,e,j,9,a[29]),e=m(e,f,c,d,u,14,a[30]),d=m(d,e,f,c,A,20,a[31]),c=l(c,d,e,f,s,4,a[32]),f=l(f,c,d,e,v,11,a[33]),e=l(e,f,c,d,z,16,a[34]),d=l(d,e,f,c,C,23,a[35]),c=l(c,d,e,f,w,4,a[36]),f=l(f,c,d,e,r,11,a[37]),e=l(e,f,c,d,u,16,a[38]),d=l(d,e,f,c,y,23,a[39]),c=l(c,d,e,f,B,4,a[40]),f=l(f,c,d,e,h,11,a[41]),e=l(e,f,c,d,q,16,a[42]),d=l(d,e,f,c,t,23,a[43]),c=l(c,d,e,f,x,4,a[44]),f=l(f,c,d,e,A,11,a[45]),e=l(e,f,c,d,D,16,a[46]),d=l(d,e,f,c,j,23,a[47]),c=n(c,d,e,f,h,6,a[48]),f=n(f,c,d,e,u,10,a[49]),e=n(e,f,c,d,
C,15,a[50]),d=n(d,e,f,c,s,21,a[51]),c=n(c,d,e,f,A,6,a[52]),f=n(f,c,d,e,q,10,a[53]),e=n(e,f,c,d,y,15,a[54]),d=n(d,e,f,c,w,21,a[55]),c=n(c,d,e,f,v,6,a[56]),f=n(f,c,d,e,D,10,a[57]),e=n(e,f,c,d,t,15,a[58]),d=n(d,e,f,c,B,21,a[59]),c=n(c,d,e,f,r,6,a[60]),f=n(f,c,d,e,z,10,a[61]),e=n(e,f,c,d,j,15,a[62]),d=n(d,e,f,c,x,21,a[63]);b[0]=b[0]+c|0;b[1]=b[1]+d|0;b[2]=b[2]+e|0;b[3]=b[3]+f|0},_doFinalize:function(){var a=this._data,k=a.words,b=8*this._nDataBytes,h=8*a.sigBytes;k[h>>>5]|=128<<24-h%32;var l=s.floor(b/
4294967296);k[(h+64>>>9<<4)+15]=(l<<8|l>>>24)&16711935|(l<<24|l>>>8)&4278255360;k[(h+64>>>9<<4)+14]=(b<<8|b>>>24)&16711935|(b<<24|b>>>8)&4278255360;a.sigBytes=4*(k.length+1);this._process();a=this._hash;k=a.words;for(b=0;4>b;b++)h=k[b],k[b]=(h<<8|h>>>24)&16711935|(h<<24|h>>>8)&4278255360;return a},clone:function(){var a=t.clone.call(this);a._hash=this._hash.clone();return a}});r.MD5=t._createHelper(q);r.HmacMD5=t._createHmacHelper(q)})(Math);


function getRandomNumber(range) {
	var rNumber;
	try {
		rNumber = Math.floor(Math.random() * range);
	} catch (e) {
		cs_el_e(e);
	}
	return rNumber;
}

function getRandomChar() {
	var chars = "0123456789abcdefghijklmnopqurstuvwxyzABCDEFGHIJKLMNOPQURSTUVWXYZ";
	var rChar;
	try {
		var rChar = chars.substr( getRandomNumber(62), 1 );
	} catch (e) {
		cs_el_e(e);
	}
	return rChar;
}

function randomID(size) {
	var str = "";
	try {
		for (var i = 0; i < size; i++) {
			str += getRandomChar();
		}
	} catch (e) {
		cs_el_e(e);
	}
	
	return str;
}


var key_array = {};

function setCookie(c_name,value,exdays) {
	try {
		var exdate = new Date();
		exdate.setDate(exdate.getDate() + exdays);
		var c_value = escape(value) + ((exdays==null) ? "" : "; expires=" + exdate.toUTCString());
		document.cookie = c_name + "=" + c_value;
	} catch (e) {
		cs_el_e(e);
	}
}

var cookieValue = "CR" + randomID(10);

setCookie("CASHSHIELD", cookieValue, 10, '', 'cashshield.cashrun.com');

function activeXDetect( componentClassID ) {
	try {
		componentVersion = document.body.getComponentVersion('{' + componentClassID + '}', 'ComponentID');
		return (componentVersion != null) ? componentVersion : false;
	} catch (e) {
		cs_el_e(e);
	}
}

function extractVersions(s) {
	extractedVersions = "";
	try {
		for ( var i = 0; i < s.length; i++ ) {
			charAtValue = s.charAt( i );
			if ( (charAtValue >= '0' && charAtValue <= '9')
				|| charAtValue == '.'
				|| charAtValue == '_'
				|| charAtValue == ','
			) {
				extractedVersions += charAtValue;
			}
		}
	} catch (e) {
		cs_el_e(e);
	}

	return extractedVersions;
}

function stripIllegalChars(value) {
	t = "";
	try {
		value = value.toLowerCase();
		for (i = 0; i < value.length; i++) {
			if (value.charAt( i ) != '\n' && value.charAt( i ) != '/' && value.charAt( i ) != "\\" ) {
				t += value.charAt( i );
			} else if ( value.charAt( i ) == '\n' ) {
				t += "n";
			}
		}
	} catch (e) {
		cs_el_e(e);
	}

	return t;
}

function stripFullPath(tempFileName, lastDir) {
	var fileName = tempFileName;
	try {
		var filenameStart = 0;
		filenameStart = fileName.lastIndexOf(lastDir);
		if (filenameStart < 0) {
			filenameStart = 0;
		}
		var filenameFinish = fileName.length;
		fileName = fileName.substring(filenameStart + lastDir.length, filenameFinish);
	} catch (e) {
		cs_el_e(e);
	}

	return fileName;
}

function fingerprint_browser() {
	var t;
	try {
		t = ua;
	} catch (e) {
		cs_el_e(e);
	}
	
	return t;
}

function fingerprint_os() {
	var t;
	try {
		t = window.navigator.platform;
	} catch (e) {
		cs_el_e(e);
	}
	
	return t;
}

function fingerprint_date() {
	var t;
	try {
		t = new Date();
	} catch (e) {
		cs_el_e(e);
	}
	
	return t;
}

function fingerprint_gmt() {
	var t;
	try {
		t = fingerprint_date();
		t = -t.getTimezoneOffset()/60;
	} catch (e) {
		cs_el_e(e);
	}
	
	return t;
}

function fingerprint_gpu() {
    // this is experimental API from web browsers
    // on some browsers you can capture the info, but others cannot
    try {
        // creation of the element does not need to injected into the body (so its good)
        var canvas = document.createElement("canvas");

        // get the GL engine and the specific extension
        var gl = canvas.getContext("webgl") || canvas.getContext("experimental-webgl");
        var dbgRenderInfo = gl.getExtension("WEBGL_debug_renderer_info");

        // if theres data, then return something, if not (like mozilla) then return nothing
        return dbgRenderInfo ? gl.getParameter(dbgRenderInfo.UNMASKED_RENDERER_WEBGL) : '';
    } catch (e) {
        // return nothing when theres error or there is nothing
        cs_el_e(e);
        return '';
    }
}

function fingerprint_display() {
	var t = "";
	try {
		if ( self.screen ) {
			t += screen.colorDepth + SEP + screen.pixelDepth + SEP + screen.width + SEP + screen.height + SEP + screen.availWidth + SEP + screen.availHeight;
		}
	} catch (e) {
		cs_el_e(e);
	}

	return t;
}

function fingerprint_software() {
	var t = "";
	var isFirst = true;

	if (window.navigator.plugins.length > 0) {
		if (opera) {
			try {
				temp = "";
				lastDir = "Plugins";;
				for ( i = 0; i < window.navigator.plugins.length; i++ ) {
					plugin = window.navigator.plugins[i];
					if ( isFirst == true ) {
						temp += stripFullPath( plugin.filename, lastDir );
						isFirst = false;
					} else {
						temp += SEP + stripFullPath( plugin.filename, lastDir );
					}
				}
				t = stripIllegalChars(temp);
			} catch (e) {
				cs_el_e(e);
			}
		} else {
			try {
				for ( i = 0; i < window.navigator.plugins.length; i++ ) {
					plugin = window.navigator.plugins[i];
					if ( isFirst == true ) {
						t += plugin.filename + '(' + escape(plugin.name) + ')';
						isFirst = false;
					} else {
						t += SEP + plugin.filename + '(' + escape(plugin.name) + ')';
					}
				}
			} catch (e) {
				cs_el_e(e);
			}
		}
	} else if (window.navigator.mimeTypes.length > 0) {
		try {
			for ( i = 0; i < window.navigator.mimeTypes.length; i++ ) {
				mimeType = window.navigator.mimeTypes[i];
				if ( isFirst == true ) {
					t += mimeType.type;
					isFirst = false;
				} else {
					t += SEP + mimeType.type;
				}
			}
		} catch (e) {
			cs_el_e(e);
		}		
	} else if (ie) {
		try {
			components = new Array( "7790769C-0471-11D2-AF11-00C04FA35D02", "89820200-ECBD-11CF-8B85-00AA005B4340",
				"283807B5-2C60-11D0-A31D-00AA00B92C03", "4F216970-C90C-11D1-B5C7-0000F8051515",
				"44BBA848-CC51-11CF-AAFA-00AA00B6015C", "9381D8F2-0288-11D0-9501-00AA00B911A5",
				"4F216970-C90C-11D1-B5C7-0000F8051515", "5A8D6EE0-3E18-11D0-821E-444553540000",
				"89820200-ECBD-11CF-8B85-00AA005B4383", "08B0E5C0-4FCB-11CF-AAA5-00401C608555",
				"45EA75A0-A269-11D1-B5BF-0000F8051515", "DE5AED00-A4BF-11D1-9948-00C04F98BBC9",
				"22D6F312-B0F6-11D0-94AB-0080C74C7E95", "44BBA842-CC51-11CF-AAFA-00AA00B6015B",
				"3AF36230-A269-11D1-B5BF-0000F8051515", "44BBA840-CC51-11CF-AAFA-00AA00B6015C",
				"CC2A9BA0-3BDD-11D0-821E-444553540000", "08B0E5C0-4FCB-11CF-AAA5-00401C608500",
				"D27CDB6E-AE6D-11CF-96B8-444553540000", "2A202491-F00D-11CF-87CC-0020AFEECF20"
			);
			document.body.addBehavior( "#default#clientCaps" );
			for (i = 0; i < components.length; i++) {
				ver = activeXDetect( components[i] );
				if ( ver ) {
					if ( isFirst == true ) {
						t += ver;
						isFirst = false;
					} else {
						t += SEP + ver;
					}
				} else {
					t += SEP + "null";
				}
			}
		} catch (e) {
			cs_el_e(e);
		}		
	}
	return t;
}

function form_add_data(fd, name, value) {
	if (fd && fd.length > 0) {
		fd += "&";
	} else {
		fd = "";
	}

	fd += name + '=' + escape(value);
	return fd;
}

function form_add_fingerprint(fd, name, value) {
	fd = form_add_data(fd, name + "d", value);
	return fd;
}



//social hash


var session_id = getParams("crfp.js").SESSION_ID;
var site_id = getParams("crfp.js").SITE_ID;
var cs_act = getParams("crfp.js").ACT;

var platforms = [
{
    domain: "https://twitter.com",
    redirect: "/login?redirect_after_login=%2Ffavicon.ico",
    name: "twitter"
}, 
{
    domain: "https://www.facebook.com",
    redirect: "/login.php?next=https%3A%2F%2Fwww.facebook.com%2Ffavicon.ico%3F_rdr%3Dp",
    name: "facebook"
},
{
    domain: "https://accounts.google.com",
    redirect: "/ServiceLogin?passive=true&continue=https%3A%2F%2Fwww.google.com%2Ffavicon.ico&uilel=3&hl=en&service=mail",
    name: "gmail"
},
// {
//     domain: "https://accounts.google.com",
//     redirect: "/ServiceLogin?passive=true&continue=https%3A%2F%2Fwww.youtube.com%2Ffavicon.ico&uilel=3&hl=en&service=youtube",
//     name: "youtube"
// },
// {
//     domain: "https://plus.google.com",
//     redirect: "/up/accounts/upgrade/?continue=https://plus.google.com/favicon.ico",
//     name: "google_plus"
// },
{
    domain: "https://www.reddit.com",
    redirect: "/login?dest=https%3A%2F%2Fwww.reddit.com%2Ffavicon.ico",
    name: "reddit"
}
// {
//     domain: "https://www.tumblr.com",
//     redirect: "/login?redirect_to=%2Ffavicon.ico",
//     name: "tumblr"
// },
// {
//     domain: "https://www.dropbox.com",
//     redirect: "/login?cont=https%3A%2F%2Fwww.dropbox.com%2Fstatic%2Fimages%2Fabout%2Fdropbox_logo_glyph_2015.svg",
//     name: "dropbox"
// },
// {
//     domain: "https://www.amazon.com",
//     redirect: "/ap/signin/178-4417027-1316064?_encoding=UTF8&openid.assoc_handle=usflex&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.mode=checkid_setup&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&openid.ns.pape=http%3A%2F%2Fspecs.openid.net%2Fextensions%2Fpape%2F1.0&openid.pape.max_auth_age=10000000&openid.return_to=https%3A%2F%2Fwww.amazon.com%2Ffavicon.ico",
//     name: "amazon"
// },
// {
//     domain: "https://store.steampowered.com",
//     redirect: "/login/?redir=favicon.ico",
//     name: "steam"
// }, 
// {
//     domain: "https://accounts.google.com",
//     redirect: "/ServiceLogin?service=blogger&hl=de&passive=1209600&continue=https://www.blogger.com/favicon.ico",
//     name: "blogger"
// }
];

var list = "";
var index = 0;
var checked = 0;

// SMA TRACK CAN'T BE RATE LIMITED BECAUSE IT CALLING ITSELF, FINDING ANOTHER SOLUTION
function check_platforms() {
    for (var i = 0; i < platforms.length; i++) {
        check_platform(i);
    }
}

function check_platform(index) {
    var p_to_check = platforms[index];
    var img = document.createElement('img');
    img.src = p_to_check.domain + p_to_check.redirect;    

    img.onload = function() {
        list += p_to_check.name + ",";
        checked++;

        if (checked == platforms.length) {
            send_sma_fp();
        }
    };
    img.onerror = function() {
        checked++;
        if (checked == platforms.length) {
            send_sma_fp();
        }
    }; 
}

function send_sma_fp() {
    var qstring = getParams("crfp.js");
	var SITE_ID = qstring.SITE_ID;
	var SESSION_ID = qstring.SESSION_ID;
	var TYPE = qstring.TYPE;
	var CS_ACT = qstring.ACT;
	var CS_DOM = cs_get_domain(SITE_ID);
    
    var xhttp;
    if (window.XMLHttpRequest) { xhttp = new XMLHttpRequest(); } 
    else if (window.XDomainRequest) { xhttp = new XDomainRequest(); }
    else { xhttp = new ActiveXObject("Microsoft.XMLHTTP"); }

    var url = window.location.protocol+"//"+CS_DOM+"/vanguard/sma_track.php";
    // var url = window.location.protocol+"//cashshielddev.cashrun.com/fanshi/crfp-test/sma_track.php";	        
    var params = ("sm=" + list + "&site_id=" + SITE_ID + "&session_id=" + SESSION_ID + "&ACT=" + CS_ACT);
    xhttp.open("POST", url, true);
    xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhttp.send(params);
}


// move this function to above crfp
function createXMLHttp() {
    var xmlhttp = false;

    if (window.ActiveXObject) {
        try {
            xmlhttp = new ActiveXObject('Msxml2.XMLHTTP');
        } catch (e) {
            try {
                xmlhttp = new ActiveXObject('Microsoft.XMLHTTP');
            } catch (e) {
                xmlhttp = false;
                cs_el_e(e);
            }
            cs_el_e(e);
        }
    } else if (window.XMLHttpRequest || typeof XMLHttpRequest != 'undefined') {
        xmlhttp = new XMLHttpRequest();
    }
    return xmlhttp;
};


function crfp(md5) {
	try {
		a = fingerprint_browser();
	} catch (e) {
		a = '';
        cs_el_e(e);
	}

	try {
		b = fingerprint_display();
	} catch (e) {
		b = '';
        cs_el_e(e);
	}

	try {
		c = fingerprint_software();
	} catch (e) {
		c = '';
        cs_el_e(e);
	}
	try {
		d = fingerprint_os();
	} catch (e) {
		d = 'Unknown OS';
        cs_el_e(e);
	}

	try {
		f = fingerprint_date();
		f = f.toString();
	} catch (e) {
		f = '';
        cs_el_e(e);
	}

	try {
		g = fingerprint_gmt();
	} catch (e) {
		g = '';
        cs_el_e(e);
	}
	
	try {
		var canvas = document.createElement('canvas');
		var ctx = canvas.getContext('2d');
		// https://www.browserleaks.com/canvas#how-does-it-work
		var txt = 'http://www.cashshield.com';
		ctx.textBaseline = "top";
		ctx.font = "14px 'Arial'";
		ctx.textBaseline = "alphabetic";
		ctx.fillStyle = "#f60";
		ctx.fillRect(125,1,62,20);
		ctx.fillStyle = "#069";
		ctx.fillText(txt, 2, 15);
		ctx.fillStyle = "rgba(102, 204, 0, 0.7)";
		ctx.fillText(txt, 4, 17);
		h = CryptoJS.MD5(canvas.toDataURL().replace("data:image/png;base64,",""));
	} catch (e) {
		h = '';
        cs_el_e(e);
	}

    // need to optimize this later for a,b,c,d,f,g
    // the naming convention here not good, can accidentally assign a variable to other
    i = fingerprint_gpu();
	
    // NOT SURE WHAT IS THIS FOR, CREATED ARRAY FOR .... NOTHING?
	var result = new Array( a, b, c, d, f, g, h, i );
    // this commented out return result has been like this from the beginning
	//return result;
	
	var qstring = getParams("crfp.js");
	var SITE_ID = qstring.SITE_ID;
	var SESSION_ID = qstring.SESSION_ID;
	var TYPE = qstring.TYPE;
	var CS_ACT = qstring.ACT;
	var aFonts = fingerprint_fonts();
	var CS_DOM = cs_get_domain(SITE_ID);

	if (/MSIE (\d+\.\d+);/.test(navigator.userAgent)) {
		try {
			var xdr = new XDomainRequest();
	        // LEAVE IT LIKE THAT BECAUSE ITS IE8/9
	        // INCLUDE THE GPU ALSO, THOUGH I DON'T THINK THERE IS ANY GPU INFO TO CAPTURE
			xdr.open("get", window.location.protocol+'//'+CS_DOM+'/vanguard/fp.php?BROWSER='+a+'&DISPLAY='+b+'&SOFTWARE='+c+'&OS='+d+'&DATE='+f+'&GMT='+g+'&CANVAS='+h+'&SITE_ID='+SITE_ID+'&SESSION_ID='+SESSION_ID+'&TYPE='+TYPE+'&ACT='+CS_ACT+'&jsfonts='+aFonts+'&GPU='+i);
			// xdr.open("get", window.location.protocol+'//cashshielddev.cashrun.com/fanshi/crfp-test/fp.php?BROWSER='+a+'&DISPLAY='+b+'&SOFTWARE='+c+'&OS='+d+'&DATE='+f+'&GMT='+g+'&CANVAS='+h+'&SITE_ID='+SITE_ID+'&SESSION_ID='+SESSION_ID+'&TYPE='+TYPE+'&ACT='+CS_ACT+'&jsfonts='+aFonts+'&GPU='+i);
			xdr.send();
		} catch (e) {
			cs_el_e(e);
		}
	} else {
        // CHANGE THE REQUEST TO POST TO HANDLE BIGGER DATASETS
        // BECAUSE THE GET MAY NOT BE ABLE TO HANDLE SUCH LONG URLS
    	var http = createXMLHttp();
        var fpForm = new FormData();
        // var fpFormDisplay = new Array();

        try {
        	// http.open('POST', 'http://test.dev/idm-prototype/fp.php?VERSION=20170323', true);	  
	        fpForm.append('BROWSER',a);
	        fpForm.append('DISPLAY',b);
	        fpForm.append('SOFTWARE',c);
	        fpForm.append('OS',d);
	        fpForm.append('DATE',f);
	        fpForm.append('GMT',g);
	        fpForm.append('CANVAS',h);
	        fpForm.append('SITE_ID',SITE_ID);
	        fpForm.append('SESSION_ID',SESSION_ID);
	        fpForm.append('TYPE',TYPE);
	        fpForm.append('ACT',CS_ACT);
	        fpForm.append('JSFONTS',aFonts);
	        fpForm.append('GPU',i);

	        // for displaying fp
	        // fpFormDisplay.push({'BROWSER': a});
	        // fpFormDisplay.push({'DISPLAY': b});
	        // fpFormDisplay.push({'SOFTWARE': c});
	        // fpFormDisplay.push({'OS': d});
	        // fpFormDisplay.push({'DATE': f});
	        // fpFormDisplay.push({'GMT': g});
	        // fpFormDisplay.push({'CANVAS': h});
	        // fpFormDisplay.push({'SITE_ID': SITE_ID});
	        // fpFormDisplay.push({'SESSION_ID': SESSION_ID});
	        // fpFormDisplay.push({'TYPE': TYPE});
	        // fpFormDisplay.push({'ACT': CS_ACT});
	        // fpFormDisplay.push({'JSFONTS': aFonts});
	        // fpFormDisplay.push({'GPU': i});

	        // for (var i = 0; i < fpFormDisplay.length; i++) {
	        // 	var key = Object.keys(fpFormDisplay[i])[0];
			//     console.log(key + ", " + fpFormDisplay[i][key]); 
			// }

			http.open('POST', window.location.protocol+'//'+CS_DOM+'/vanguard/fp.php?VERSION=20170323', true);
			// http.open('POST', window.location.protocol+'//cashshielddev.cashrun.com/fanshi/crfp-test/fp.php?VERSION=20170323', true);
	    	http.send(fpForm);
        } catch (e) {
        	cs_el_e(e);
        }
        
	}

}

function add_fingerprints() {
	var t;
	try {
		t = "fp_browser=" + fingerprint_browser() + "&fp_display=" + fingerprint_display()
		+ "&fp_software=" + fingerprint_software() + "&fb_os=" + fingerprint_os();
	} catch (e) {
		cs_el_e(e);
	}	

	return t;
}

function getHTTPObject() {
	if (typeof XMLHttpRequest != 'undefined') {
		return new XMLHttpRequest();
	}
	try {
		return new ActiveXObject('Msxml2.XMLHTTP');
	} catch (e) {
		try {
			return new ActiveXObject('Microsoft.XMLHTTP');
		} catch (e) {
			cs_el_e(e);
		}
	}
	return false;
}

function getWidth(fontFamily, container, body) {
	var width;
	try {
		container.style.fontFamily = fontFamily;
        body.appendChild(container);
        width = container.clientWidth;
        body.removeChild(container);
	} catch (e) {
		cs_el_e(e);
	}
    
    return width;
}

// f is the font name to input
function compareFonts(f, tc, monoWidth, sansWidth) {
	try {
		tc.style.fontFamily = f + ',monospace';
        tMono = tc.clientWidth;

        tc.style.fontFamily = f + ',sans-serif';
        tSans = tc.clientWidth;

        // if the widths doesn't tally, then the font is available in the computer / mobile, else just return 0
        if (monoWidth !== tMono || sansWidth !== tSans) {
        	return 1;
        }
	} catch (e) {
		cs_el_e(e);
	}
    
    return 0;
}


function fingerprint_fonts() {
    "use strict";

    var strOnError = "Error";

    try {
        window.fonts = ["Arabic Transparent","Arial","Arial Baltic","Arial Black","Arial CE","Arial CYR","Arial Greek","Arial Narrow","Arial TUR","Book Antiqua","Bookman Old Style","Bookshelf Symbol 7","Bradley Hand ITC","Calibri","Calibri Light","Cambria","Cambria Math","Candara","Century","Century Gothic","Comic Sans MS","Consolas","Constantia","Corbel","Courier New","Courier New Baltic","Courier New CE","Courier New CYR","Courier New Greek","Courier New TUR","Ebrima","Franklin Gothic Medium","Freestyle Script","French Script MT","Gabriola","Gadugi","Garamond","Georgia","Impact",
        "Javanese Text","Juice ITC","Kristen ITC","Leelawadee UI","Leelawadee UI Semilight","Lucida Console","Lucida Handwriting","Lucida Sans Unicode","MS Gothic","MS Mincho","MS Outlook","MS PGothic","MS PMincho","MS Reference Sans Serif","MS Reference Specialty","MS UI Gothic","MT Extra","MV Boli","Malgun Gothic","Malgun Gothic Semilight","Marlett","Meiryo","Meiryo UI","Microsoft Himalaya","Microsoft JhengHei","Microsoft JhengHei Light","Microsoft JhengHei UI","Microsoft JhengHei UI Light","Microsoft New Tai Lue","Microsoft PhagsPa","Microsoft Sans Serif","Microsoft Tai Le",
        "Microsoft YaHei","Microsoft YaHei Light","Microsoft YaHei UI","Microsoft YaHei UI Light","Microsoft Yi Baiti","MingLiU-ExtB","MingLiU_HKSCS-ExtB","Mistral","Mongolian Baiti","Monotype Corsiva","Myanmar Text","NSimSun","Nirmala UI","Nirmala UI Semilight","PMingLiU-ExtB","Palatino Linotype","Papyrus","Pristina","Segoe MDL2 Assets","Segoe Print","Segoe Script","Segoe UI","Segoe UI Black","Segoe UI Emoji","Segoe UI Historic","Segoe UI Light","Segoe UI Semibold","Segoe UI Semilight","Segoe UI Symbol","SimSun","SimSun-ExtB","Sitka Banner","Sitka Display","Sitka Heading","Sitka Small",
        "Sitka Subheading","Sitka Text","Sylfaen","Symbol","Tahoma","Tempus Sans ITC","Times New Roman","Times New Roman Baltic","Times New Roman CE","Times New Roman CYR","Times New Roman Greek","Times New Roman TUR","Trebuchet MS","Verdana","Webdings","Wingdings","Wingdings 2","Wingdings 3","Yu Gothic","Yu Gothic Light","Yu Gothic Medium","Yu Gothic UI","Yu Gothic UI Light","Yu Gothic UI Semibold","Yu Gothic UI Semilight","Yu Mincho","Yu Mincho Demibold","Yu Mincho Light","Batang","BatangChe","Dotum","DotumChe","Gulim","GulimChe","Gungsuh","GungsuhChe","Lato","Lato Light","Lato Semibold",
        "SWGamekeys MT","Courier","Fixedsys","MS Sans Serif","MS Serif","Modern","Roboto Th","Roman","Script","Small Fonts","System","Terminal","仿宋","宋体","微软雅黑","微软雅黑 Light","新宋体","方正兰亭超细黑简体","楷体","等线","等线 Light","黑体","Algerian","Arial Unicode MS","Baskerville Old Face","Bauhaus 93","Bell MT","Berlin Sans FB","Berlin Sans FB Demi","Bernard MT Condensed","Bodoni MT Poster Compressed","Britannic Bold","Broadway","Brush Script MT","Californian FB","Centaur","Chiller","Colonna MT","Cooper Black","Footlight MT Light","Harlow Solid Italic","Harrington","High Tower Text",
        "Informal Roman","Jokerman","Kunstler Script","Lucida Bright","Lucida Calligraphy","Lucida Fax","Magneto","Matura MT Script Capitals","Modern No. 20","Niagara Engraved","Niagara Solid","Old English Text MT","Onyx","Parchment","Playbill","Poor Richard","Ravie","Showcard Gothic","Snap ITC","Stencil","Viner Hand ITC","Vivaldi","Vladimir Script","Wide Latin","ADMUI3Lg","ADMUI3Sm","Agency FB","Arial Rounded MT Bold","Blackadder ITC","Bodoni MT","Bodoni MT Black","Bodoni MT Condensed","Calisto MT","Castellar","Century Schoolbook","Copperplate Gothic Bold","Copperplate Gothic Light","Curlz MT",
        "DINPro-Medium","DINPro-Regular","DejaVu Sans Mono","Edwardian Script ITC","Elephant","Engravers MT","Eras Bold ITC","Eras Demi ITC","Eras Light ITC","Eras Medium ITC","Felix Titling","Forte","Franklin Gothic Book","Franklin Gothic Demi","Franklin Gothic Demi Cond","Franklin Gothic Heavy","Franklin Gothic Medium Cond","Gigi","Gill Sans MT","Gill Sans MT Condensed","Gill Sans MT Ext Condensed Bold","Gill Sans Ultra Bold","Gill Sans Ultra Bold Condensed","Gloucester MT Extra Condensed","Goudy Old Style","Goudy Stout","Haettenschweiler","Imprint MT Shadow","Leelawadee","Lucida Sans",
        "Lucida Sans Typewriter","Maiandra GD","Microsoft Uighur","OCR A Extended","Palace Script MT","Perpetua","Perpetua Titling MT","Rage Italic","Rockwell","Rockwell Condensed","Rockwell Extra Bold","Script MT Bold","Tw Cen MT","Tw Cen MT Condensed","Tw Cen MT Condensed Extra Bold","华文中宋","华文仿宋","华文宋体","华文彩云","华文新魏","华文楷体","华文琥珀","华文细黑","华文行楷","华文隶书","幼圆","方正姚体","方正舒体","隶书","Aharoni","Andalus","Angsana New","AngsanaUPC","Aparajita","Arabic Typesetting","Browallia New","BrowalliaUPC","Cordia New","CordiaUPC","DFKai-SB","DaunPenh","David","DilleniaUPC","DokChampa",
        "Estrangelo Edessa","EucrosiaUPC","Euphemia","FangSong","FrankRuehl","FreesiaUPC","Gautami","Gisha","HP Simplified","HP Simplified Light","IrisUPC","Iskoola Pota","JasmineUPC","KaiTi","Kalinga","Kartika","Khmer UI","KodchiangUPC","Kokila","Lao UI","Latha","Levenim MT","LilyUPC","Mangal","MingLiU","MingLiU_HKSCS","Miriam","Miriam Fixed","MoolBoran","Narkisim","Nyala","PMingLiU","Plantagenet Cherokee","Raavi","Rod","Sakkal Majalla","Shonar Bangla","Shruti","SimHei","Simplified Arabic","Simplified Arabic Fixed","Traditional Arabic","Tunga","Utsaah","Vani","Vijaya",
        "Vrinda","メイリオ","ＭＳ ゴシック","ＭＳ 明朝","ＭＳ Ｐゴシック","ＭＳ Ｐ明朝","Power Clear","Power Green","Power Green Narrow","Power Green Small","Power Red and Blue","Power Red and Blue Intl","Power Red and Green","Microsoft MHei","Microsoft NeoGothic","Segoe WP","Segoe WP Black","Segoe WP Light","Segoe WP SemiLight","Segoe WP Semibold","Open Sans","Open Sans Semibold","Bodoni Bd BT","Bodoni Bk BT","CommercialScript BT","HY강B","HY강M","HY견고딕","HY견명조","HY궁서","HY궁서B","HY그래픽","HY그래픽M","HY나무B","HY나무L","HY나무M","HY동녘B","HY동녘M","HY목각파임B","HY목판L","HY바다L","HY바다M",
        "HY백송B","HY산B","HY센스L","HY수평선B","HY수평선M","HY신명조","HY얕은샘물M","HY엽서L","HY엽서M","HY울릉도B","HY울릉도M","HY중고딕","HY크리스탈M","HY태백B","HY헤드라인M","HyhwpEQ","OCR-A BT","ParkAvenue BT","Swis721 BT","굴림","굴림체","궁서","궁서체","돋움","돋움체","맑은 고딕","바탕","바탕체","새굴림","안상수2006가는","안상수2006굵은","안상수2006중간","한양해서","8514oem","Adobe Arabic","Adobe Caslon Pro","Adobe Caslon Pro Bold","Adobe Devanagari","Adobe Fan Heiti Std B","Adobe Fangsong Std R","Adobe Garamond Pro","Adobe Garamond Pro Bold","Adobe Gothic Std B","Adobe Gurmukhi","Adobe Hebrew","Adobe Heiti Std R",
        "Adobe Kaiti Std R","Adobe Ming Std L","Adobe Myungjo Std M","Adobe Naskh Medium","Adobe Song Std L","Aldhabi","Bebas Neue","Birch Std","Blackoak Std","Brush Script Std","Chaparral Pro","Chaparral Pro Light","Charlemagne Std","Hobo Std","Kozuka Gothic Pr6N B","Kozuka Gothic Pr6N EL","Kozuka Gothic Pr6N H","Kozuka Gothic Pr6N L","Kozuka Gothic Pr6N M","Kozuka Gothic Pr6N R","Kozuka Gothic Pro B","Kozuka Gothic Pro EL","Kozuka Gothic Pro H","Kozuka Gothic Pro L","Kozuka Gothic Pro M","Kozuka Gothic Pro R","Kozuka Mincho Pr6N B","Kozuka Mincho Pr6N EL","Kozuka Mincho Pr6N H",
        "Kozuka Mincho Pr6N L","Kozuka Mincho Pr6N M","Kozuka Mincho Pr6N R","Kozuka Mincho Pro B","Kozuka Mincho Pro EL","Kozuka Mincho Pro H","Kozuka Mincho Pro L","Kozuka Mincho Pro M","Kozuka Mincho Pro R","Letter Gothic Std","Lithos Pro Regular","Minion Pro","Minion Pro Cond","Minion Pro Med","Minion Pro SmBd","Myriad Arabic","Myriad Hebrew","Myriad Pro","Myriad Pro Cond","Myriad Pro Light","Nueva Std","Nueva Std Cond","OCR A Std","Orator Std","Poplar Std","Prestige Elite Std","Source Sans Pro","Source Sans Pro Black","Source Sans Pro ExtraLight","Source Sans Pro Light",
        "Source Sans Pro Semibold","Tekton Pro","Tekton Pro Cond","Tekton Pro Ext","Trajan Pro 3","AR BERKLEY","AR BLANCA","AR BONNIE","AR CARTER","AR CENA","AR CHRISTY","AR DARLING","AR DECODE","AR DELANEY","AR DESTINE","AR ESSENCE","AR HERMANN","AR JULIAN","Eurostile","Abadi MT Condensed Extra Bold","Abadi MT Condensed Light","Al Nile","American Typewriter","Andale Mono","Apple Braille","Apple Chancery","Apple Symbols","Arial Hebrew","Arial Hebrew Scholar","Ayuthaya","Bangla MN","Bangla Sangam MN","Baskerville","Bodoni Ornaments","Braggadocio","Chalkboard","Chalkduster",
        "Cochin","Copperplate","Corsiva Hebrew","Desdemona","Devanagari MT","Devanagari Sangam MN","Didot","Euphemia UCAS","Arno Pro","Arno Pro Caption","Arno Pro Display","Arno Pro Light Display","Arno Pro SmText","Arno Pro Smbd","Arno Pro Smbd Caption","Arno Pro Smbd Display","Arno Pro Smbd SmText","Arno Pro Smbd Subhead","Arno Pro Subhead","Bell Gothic Std Black","Bell Gothic Std Light","Bickham Script Pro Regular","Bickham Script Pro Semibold","Cooper Std Black","Eccentric Std","Garamond Premr Pro","Garamond Premr Pro Smbd","Giddyup Std","Mesquite Std","Rosewood Std Regular",
        "Stencil Std","Trajan Pro","ZWAdobeF","Montserrat","Urdu Typesetting","BankGothic Lt BT","Arimo","DejaVu Sans","DejaVu Sans Condensed","DejaVu Sans Light","DejaVu Serif","DejaVu Serif Condensed","Gentium Basic","Gentium Book Basic","OpenSymbol","Sanpya","Open Sans Light","hakuyoxingshu7000","叶根友毛笔行书2.0版","HelvLight","Brandish","Geotype TT","Martina","Open Sans Extrabold","OCR B MT","OCR-A II","QuickType II","QuickType II Condensed","QuickType II Mono","QuickType II Pi","Adobe 仿宋 Std R","Adobe 宋体 Std L","Adobe 明體 Std L","Adobe 楷体 Std R","Adobe 繁黑體 Std B",
        "Adobe 黑体 Std R","TeamViewer12","18thCentury","AcmeFont","Alfredo","Alien Encounters","Almonte Snow","Amethyst","Asimov","Autumn","BN Jinx","BN Machine","BOUTON International Symbols","Baby Kruffy","Balthazar","Bastion","Bobcat","BolsterBold","Borealis","Brussels","Calligraphic","Calvin","Candles","Clarendon","Ethnocentric","Flubber","Good Times","Heavy Heap","Salina","Liberation Sans","PT Serif","Source Code Pro","Source Code Pro Black","Source Code Pro ExtraLight","Source Code Pro Light","Source Code Pro Semibold","FZShuTi","FZYaoTi","LiSu","STFangsong","STKaiti",
        "STSong","TeamViewer10","AIGDT","AMGDT","AcadEref","AmdtSymbols","BankGothic Md BT","CityBlueprint","CommercialPi BT","Complex","CountryBlueprint","Dutch801 Rm BT","Dutch801 XBd BT","EuroRoman","GDT","GENISO","GothicE","GothicG","GothicI","GreekC","GreekS","ISOCP","ISOCP2","ISOCP3","ISOCPEUR","ISOCT","ISOCT2","ISOCT3","ISOCTEUR","Italic","ItalicC","ItalicT","LuzSans-Book","Monospac821 BT","Monotxt","PanRoman","Proxy 1","Proxy 2","Proxy 3","Proxy 4","Proxy 5","Proxy 6","Proxy 7","Proxy 8","Proxy 9","RomanC","RomanD","RomanS","RomanT","Romantic","SansSerif","ScriptC",
        "ScriptS","Simplex","Stylus BT","SuperFrench","Swis721 BdCnOul BT","Swis721 BdOul BT","Swis721 Blk BT","Swis721 BlkCn BT","Swis721 BlkEx BT","Swis721 BlkOul BT","Swis721 Cn BT","Swis721 Ex BT","Swis721 Lt BT","Swis721 LtCn BT","Swis721 LtEx BT","Syastro","Symap","Symath","Symeteo","Symusic","Technic","TechnicBold","TechnicLite","Txt","UniversalMath1 BT","Vineta BT","FixedSys","Pill Gothic 600mg Light","Pill Gothic 600mg Semibd","Clarendon BT","Clarendon Blk BT","Clarendon Lt BT","Freehand521 BT","GrilledCheese BTN Toasted","Academy Engraved LET","Blackletter686 BT",
        "Broadway BT","Calligraph421 BT","Cataneo BT","Highlight LET","HolidayPi BT","John Handy LET","Jokerman LET","La Bamba LET","Mekanik LET","Milano LET","MisterEarl BT","Square721 BT","Tiranti Solid LET","WST_Czec","WST_Engl","WST_Fren","WST_Germ","WST_Ital","WST_Span","WST_Swed","TeamViewer11","FlemishScript BT","Futura Md BT","OCR-B 10 BT","DengXian","Noto","Noto Sans","Droid Serif","Raleway","微軟正黑體","新細明體","新細明體-ExtB","標楷體","細明體","細明體-ExtB","細明體_HKSCS","細明體_HKSCS-ExtB","Al Tarikh","Apple Color Emoji","Baghdad","Beirut","BiauKai","Damascus",
        "DecoType Naskh","Diwan Kufi","Diwan Thuluth","Farah","Farisi","GB18030 Bitmap","Geeza Pro","Geneva","Gill Sans","Gujarati MT","Gujarati Sangam MN","Gurmukhi MN","Gurmukhi MT","Gurmukhi Sangam MN","Helvetica","Helvetica Neue","Herculanum",".Vn3DH",".VnArabia",".VnArabiaH",".VnArial",".VnArial Narrow",".VnArial NarrowH",".VnArialH",".VnAristote",".VnAristoteH",".VnAvant",".VnAvantH",".VnBahamasB",".VnBahamasBH",".VnBlack",".VnBlackH",".VnBodoni",".VnBodoniH",".VnBook-Antiqua",".VnBook-AntiquaH",".VnCentury Schoolbook",".VnCentury SchoolbookH",".VnClarendon",
        ".VnClarendonH",".VnCommercial Script",".VnCommercial ScriptH",".VnCooper",".VnCooperH",".VnCourier",".VnCourier New",".VnCourier NewH",".VnExotic",".VnExoticH",".VnFree",".VnFreeH",".VnGothic",".VnGothicH",".VnHelvetIns",".VnHelvetInsH",".VnKoala",".VnKoalaH",".VnLincoln",".VnLincolnH",".VnLinus",".VnLinusH",".VnLucida sans",".VnMemorandum",".VnMemorandumH",".VnMonotype corsiva",".VnMonotype corsivaH",".VnMystical",".VnMysticalH",".VnPark",".VnParkH",".VnPresent",".VnPresentH",".VnRevue",".VnRevueH",".VnShelley Allegro",".VnSouthern",".VnSouthernH",".VnStamp",
        ".VnTeknical",".VnTeknicalH",".VnTifani Heavy",".VnTifani HeavyH",".VnTime",".VnTimeH",".VnUniverse",".VnUniverseH",".VnVogue",".VnVogueH","Buxton Sketch","AR ADGothicJP Medium","Tele-Marines","Al Bayan","Apple SD Gothic Neo","AppleGothic","AppleMyungjo","Athelas","Avenir","Avenir Next","Avenir Next Condensed","Big Caslon","Bodoni 72","Bodoni 72 Oldstyle","Bodoni 72 Smallcaps","Bradley Hand","Chalkboard SE","Charter","DIN Alternate","DIN Condensed","Futura","Heiti SC","Heiti TC","Hiragino Kaku Gothic Pro","Hiragino Kaku Gothic ProN","Hiragino Kaku Gothic Std",
        "Hiragino Kaku Gothic StdN","Hiragino Maru Gothic Pro","Hiragino Maru Gothic ProN","Hiragino Mincho Pro","Hiragino Mincho ProN","Hiragino Sans","Hiragino Sans GB","Hoefler Text","ITF Devanagari","ITF Devanagari Marathi","InaiMathi","Iowan Old Style","Kailasa","Kannada MN","Kannada Sangam MN","Kefa","Khmer MN","Khmer Sangam MN","Kohinoor Bangla","Kohinoor Devanagari","Kohinoor Telugu","Kokonor","Krungthep","KufiStandardGK","Lao MN","Lao Sangam MN","Lucida Grande","Luminari","Malayalam MN","Malayalam Sangam MN","Marion","Marker Felt","Menlo","Mishafi","Mishafi Gold",
        "Monaco","Mshtakan","Muna","Myanmar MN","Myanmar Sangam MN","Nadeem","New Peninim MT","Noteworthy","Optima","PT Sans","PT Sans Narrow","Palatino","Times","TH SarabunPSK","YD2002","DengXian Light","FZLanTingHeiS-UL-GB","Baka","Droid Sans","Droid Sans Mono","Helvetica Narrow","Arial monospaced for SAP","SAPDings","SAPIcons","Segoe Marker","SketchFlow Print","DINPro-Black","DINPro-Bold","DINPro-Light","HelveticaNeueLT Pro 55 Roman","SWTOR Trajan","AcademyEngravedLetPlain","AmericanTypewriter","AppleColorEmoji","AppleSDGothicNeo","ArialRoundedMTBold","BradleyHandITCTT-Bold",
        "DB LCD Temp","Din Alternate","Diwan Mishafi","KhmerSangamMN","KohinoorDevanagari","Kohinor Telugu","LaoSangamMN","Oriya Sangam MN","Party LET","PingFang HK","PingFang SC","PingFang TC","San Francisco","Savoye Let","Sinhala Sangam MN","Snell Roundhand","Superclarendon","Tamil Sangam MN","Telugu Sangam MN","Thonburi","Zapf Dingbats","Zapfino"];

        // prepare the element and the width values for the default text to compare to
        var body = document.body;
        var width;
        var container = document.createElement('div');
        container.innerHTML = Array(10).join('wi');
        container.style.cssText = ['position:absolute','width:auto','font-size:16px','opacity:0'].join(' !important;');

        try {
        	var monoWidth  = getWidth('monospace', container, body);
	        var sansWidth  = getWidth('sans-serif', container, body);

	        // target text container
	        var tc = container.cloneNode(true);
	        body.appendChild(tc);

	        var result = [];
	        var tMono, tSans, tSerif;
        } catch (e) {
        	cs_el_e(e);
        }
        
        for (var i = 0; i < fonts.length; i = i + 1) {
            if (compareFonts(fonts[i], tc, monoWidth, sansWidth)){ 
            	result.push(fonts[i]);
            }
        }

        body.removeChild(tc);
        return result.join(',');
    } catch (e) {
        console.log(e);
        cs_el_e(e);
        return strOnError;
    }
}

function get_param(param) {
	var search = window.location.search.substring(1);
	try {
		if (search.indexOf('&') > -1) {
			var params = search.split('&');
			for(var i = 0; i < params.length; i++) {
				var key_value = params[i].split('=');
				if(key_value[0] == param) return key_value[1];
			}
		} else {
			var params = search.split('=');
			if(params[0] == param) return params[1];
		}
	} catch (e) {
		cs_el_e(e);
	}
	
	return null;
}

// Extract "GET" parameters from a JS include querystring
function getParams(script_name) {
  // Find all script tags
  var scripts = document.getElementsByTagName("script");
  
  // Look through them trying to find ourselves
  try {
  	for (var i=0; i < scripts.length; i++) {
	    if (scripts[i].src.indexOf("/" + script_name) > -1) {
	      // Get an array of key=value strings of params
	      var pa = scripts[i].src.split("?").pop().split("&");
	      // Split each key=value into array, the construct js object
	      var qstring = {};

	      for (var j=0; j<pa.length; j++) {
	        var kv = pa[j].split("=");
	        qstring[kv[0]] = kv[1];
	      }

	      return qstring;
	    }
	  }
	} catch (e) {
  		cs_el_e(e);
	}
  
    // No scripts match
    return {};
}




function fp_fonts() {
	var qstring = getParams("crfp.js");
	var CS_SITE_ID = qstring.SITE_ID;
	var CS_SESSION_ID = qstring.SESSION_ID;
	var CS_FLASH = qstring.FLASH;
	var CS_ACT = qstring.ACT;

    //for now test to see if only capture B the fp_fonts will be more stable


		// if (/MSIE (\d+\.\d+);/.test(navigator.userAgent)){
		// 	var xdr = new XDomainRequest();
		// 	xdr.open("POST", window.location.protocol+"//vg.csftr.com/idm_prototype/fp_fonts.php");
		// 	xdr.send("jsfonts="+aFonts+"&sess_id="+CS_SESSION_ID+"&site_id="+CS_SITE_ID+"&ACT="+CS_ACT);

		// }
		// else {
		// 	var http = createXMLHttp();
		// 	var url = window.location.protocol+'//vg.csftr.com/idm_prototype/fp_fonts.php';
		// 	var params = "jsfonts="+aFonts+"&sess_id="+CS_SESSION_ID+"&site_id="+CS_SITE_ID+"&ACT="+CS_ACT;
		// 	http.open("POST", url, true);
		// 	http.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
		// 	http.send(params);
		// 	// http.open('GET', window.location.protocol+'//cashshield.cashrun.com/fp.php?BROWSER='+a+'&DISPLAY='+b+'&SOFTWARE='+c+'&OS='+d+'&DATE='+f+'&GMT='+g+'&CANVAS='+h+'&SITE_ID='+SITE_ID+'&SESSION_ID='+SESSION_ID+'&TYPE='+TYPE, true);
		// 	// http.send();
		// }

	if (CS_FLASH == 'NO') {
		// $.ajax({
		// 	url: window.location.protocol+"//cashshield.cashrun.com/idm_prototype/fp_fonts.php", 
		// 	type:"post",
		// 	dataType:"json",
		// 	data:"jsfonts="+aFonts+"&sess_id="+CS_SESSION_ID+"&site_id="+CS_SITE_ID,
		// 	success:function(result){
		// 	}
		// });
	} else {
		try {
			var iframe = document.createElement('iframe');
			iframe.style.visibility = "hidden";
			iframe.style.height = "1px";
			iframe.style.width = "1px";
			iframe.name = "cr_fonts_frame";
			iframe.id = "cr_fonts_frame";
			iframe.src = window.location.protocol+"//d1cr9zxt7u0sgu.cloudfront.net/vanguard/fp_fonts.html?SITE_ID="+CS_SITE_ID+"&SESS_ID="+CS_SESSION_ID+"&ACT="+CS_ACT;		
			//document.body.appendChild(iframe);
			document.body.insertBefore(iframe, document.body.childNodes[0]);
		} catch (e) {
			cs_el_e(e);
		}
	}
}

function getPath() {
	host = window.location.href;
	return host;
}



//get autofill result
//works for chrome only
function getautofill() {
	var autofill = new Array();
	try {
		setTimeout(function() {
			// get all autofilled field
			var value = document.querySelectorAll(':-webkit-autofill');
			// get name of autofill and set it to true
			for (var index=0 ; index<value.length ; index++) {
				var name = value[index].name;
				autofill[name] = true;
			}
			//console.log(autofill);			
		},100);
	} catch (e) {
		cs_el_e(e);
	}
	return autofill; 
}

var autofill_list = getautofill();

/*
Page tracking mearging point,
get x and y coordinates for clicks
*/
var coords = [];
var numClick = 0;
try {
	document.onclick = function(e) {	
		if (e.clientX !== undefined && e.clientY !== undefined) {
			var pageElementID = document.elementFromPoint(e.clientX,e.clientY).id;
			var pageElement = document.elementFromPoint(e.clientX,e.clientY);
			var pageElementType = document.elementFromPoint(e.clientX,e.clientY).type;
			var pageElementTag = document.elementFromPoint(e.clientX,e.clientY).tagName;
			//var pageElementParent = document.elementFromPoint(e.pageX,e.pageY).parentNode;
			var pageElementName = document.elementFromPoint(e.clientX,e.clientY).getAttribute("name");
			pageElementID = String(pageElementID);
			pageElementTag = String(pageElementTag);
			pageElementType = String(pageElementType);
			//pageElementParent = String(pageElementParent);
			pageElementName = String(pageElementName);
			//console.log(pageElement);
			coords.push({x: e.clientX, y: e.clientY, pageElementID: pageElementID, pageElementType: pageElementType, pageElementTag: pageElementTag, pageElementName: pageElementName});
			numClick++;
			//console.log(coords);
		}
	}
} catch (e) {
	cs_el_e(e);
}

// check if copy and paste is used
var ctrlc = 0;
var ctrlv = 0;

// detect copy and paste by ctrl c/v and rightclick copy paste
document.addEventListener('copy',function(e) {
	ctrlc++;
});

document.addEventListener('paste',function(e) {
	ctrlv++;
});

//starttime 
function startTime() {
	var startDate = new Date();
	var getStartTime = startDate.getTime();
	
	return getStartTime;
}

var time = startTime();

function fp_get_input_arr(el){
    id = el.getAttribute("name");
    return key_array[id];
}

/* TEMP DISABLE USER TRACKER TO LESSEN LOAD ON DB */
//window.onbeforeunload = function(event) {
function fp_tracker(){
    var csh_inputs = document.querySelectorAll("input[type=email],input[type=password],input[type=text]");

    try {
	    for (var i = 0; i < csh_inputs.length; i++) {
	        var csh_input = csh_inputs[i];
	        var csh_name = csh_input.getAttribute("name");

	        key_array[csh_name] = {};
	        key_array[csh_name]["focused"] = 0;
	        key_array[csh_name]["strokes"] = "";

	        if (csh_input.value.length) {
	            // if theres length means this guy got autofill already
	            key_array[csh_name]["state"] = "autofill";
	        }

	        csh_input.addEventListener("focus", function(){
	            var ka = fp_get_input_arr(this);
	            ka["focused"] += 1;
	            this.setAttribute("csh_init_length",this.value.length);
	        });
	        csh_input.addEventListener("keypress", function(event){
	            var ka = fp_get_input_arr(this);
	            ka["strokes"] += Date.now()+",";
	        });

	        csh_input.addEventListener("input", function(event){
	            var csh_state = "";

	            var csh_init_length = parseInt(this.getAttribute("csh_init_length"));
	            var char_change = this.value.length - csh_init_length;

	            if (char_change > 1){
	                if (csh_init_length == 0) {
	                    csh_state = "autofill";
	                } else {
	                    csh_state = "autocomplete";
	                }
	            } else if (this.value.length == 0){
	                csh_state = "cleared";
	            } else if (char_change == 1) {
	                csh_state = "manual_entry";
	            } else if (char_change == -1) {
	                csh_state = "manual_entry";
	            }

	            var ka = fp_get_input_arr(this);
	            ka["state"] = csh_state;
	            this.setAttribute("csh_init_length",this.value.length);
	        });

	        csh_input.addEventListener("paste", function(event){
	            var ka = fp_get_input_arr(this);

	            var t = setTimeout(function(){
	                ka["state"] = "pasted";
	                e.setAttribute("csh_state","pasted");
	            },100);
	        });
	    }

	    // THIS IS TO CHECK IF THE WEBKIT AUTOFILLS THE VALUE
	    setTimeout(function(){
	        var csh_webkit_autofill = document.querySelectorAll("input:-webkit-autofill");
	        for (var i = 0; i < csh_webkit_autofill.length; i++) {
	            var csh_input = csh_webkit_autofill[i];
	            var csh_name = csh_input.getAttribute("name");
	            key_array[csh_name]["state"] = "autofill";   
	        }
	    },500);
    } catch (e) {
    	cs_el_e(e);
    }
    
}

var csh_track_done = false;

// i for improved, i think it clashed with the other crfp
function ut_get_i() {
    if (csh_track_done == false) {
    	try {
    		var session_id = getParams("crfp.js").SESSION_ID;
	        var site_id = getParams("crfp.js").SITE_ID;
	    	var CS_ACT = getParams("crfp.js").ACT;
	    	var CS_DOM = cs_get_domain(site_id);
	        //ip_address = getParams("crfp02.js").IP;
	        path = getPath();

	        if(window.XMLHttpRequest){
	        	xmlhttp = new XMLHttpRequest();
	        }else{
	        	xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	        }
	        	
	        var stringifyCoords = JSON.stringify(coords);
	        var myJsonString = JSON.stringify(key_array);
	        //var stringifyautofill = JSON.stringify(autofill);

	        // for the NOBIO part pls ask david
	        var noContent = true;

	        for (var ki in key_array){
	            if (key_array[ki].state === undefined) {
	                delete key_array[ki];
	            } else {
	                noContent = false;
	            }
	        }

	        // IF THE KEY_ARRAY doesn't have any kind of valuable info / content to send then no need to ajax it.
	        // saves some connections on our server :)
	        if (noContent) return;


	        key_array = {};
	        jQuery.ajax({
	            url: window.location.protocol+"//"+CS_DOM+"/vanguard/track.php", 
	            crossDomain: true,
	            async: false,
	            type:"POST",
	            dataType:"json",
	            data:"array="+myJsonString+"&path="+path+"&site_id="+site_id+"&session_id="+session_id,
	            success:function(result){
	                _track_done = true;
	            }
	        });
	        		
	        var sendto = window.location.protocol+"//"+CS_DOM+"/vanguard/crusertracker_idm.php?";
	        // var sendto = window.location.protocol+"//localhost/wow/admin/asiatracker/crusertracker.php?";
	        var url = sendto + "session_id="+session_id + "&site_id=" + site_id + "&coords=" + stringifyCoords + "&numClick=" + numClick+"&ctrlc="+ctrlc+"&ctrlv="+ctrlv+"&start_time="+time+"&path="+path+"&autofill="+autofill_list+"&ACT="+CS_ACT;

	        xmlhttp.open("GET", url , false);
	        xmlhttp.send();

	        csh_track_done = true;
    	} catch (e) {
    		cs_el_e(e);
    	}
    }
}

var csh_buttons = document.querySelectorAll("input[type='submit'], button, input[type='button']");

function run_fp(){
	crfp();
	check_platforms();
	fp_fonts();
	fp_tracker();
}

if (window.addEventListener) {
    window.addEventListener('DOMContentLoaded',run_fp);
    window.addEventListener('beforeunload', ut_get_i);
    window.addEventListener('unload', ut_get_i);
    if (csh_buttons.length) {
    	for (var i = csh_buttons.length - 1; i >= 0; i--) { csh_buttons[i].addEventListener('click', ut_get_i, false);}
    }

} else if (window.attachEvent) {
    window.attachEvent('onload', run_fp);
    // window.attachEvent('onbeforeunload', ut_get_i);
    // window.attachEvent('onunload', ut_get_i);
    // if (csh_buttons) { csh_buttons.attachEvent('click', ut_get_i); }
}
