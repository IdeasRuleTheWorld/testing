/**
 * Global js variables here related to form-commons.
 */
var skipLoadingScreen = false;


$(document).ready(function() {
    initLoadingScreen(); // this function MUST come first

    /* ------------- Disable Enter Key ------------- */
    var isTextfield = false;
    $("form").bind("keypress", function(e) {
        var focusElement = $(document.activeElement);
        if (e.keyCode == 13) {
            if (focusElement.hasClass("inputfield-enterkey-enabled")) {
                return true;
            } else {
                return false;
            }
        }
    });
    /* ------------- Disable Enter Key ------------- */

    /* ------------- Custom Google Search ------------- */
    initSearchForm();
    /* ------------- Custom Google Search ------------- */

    initializeNumerInputField();

    intializeMobileNav();
});

/**
 * Ajax start global handler.
 */
$(document).ajaxStart(function(e) {
    showLoadingScreen();
});

/**
 * Ajax complete global handler.
 */
$(document).ajaxComplete(function(e) {
    hideLoadingScreen();
});

/**
 * Ajax before send global handler.
 */
$(document).ajaxSend(function(event, request, settings) {
    if (settings.type == 'POST') {
        var attrName = $("input[name^='CSRFToken']").attr("name");
        var val = $("input[name^='CSRFToken']").val();
        var typeOf = typeof settings.data;
        if (typeOf == "object") {
            settings.data.append(attrName, val);
        } else if (typeOf == "string") {
            if (settings.data.indexOf(attrName) == -1) {
                settings.data += "&" + attrName + "=" + val;
            }
        }
    }
});

/**
 * Window load global handler.
 */
$(window).load(function() {
    hideLoadingScreen();
});

/**
 * Window before unload global handler.
 */
$(window).on("beforeunload", function() {
    if (!skipLoadingScreen) {
        showLoadingScreen();
    }
    skipLoadingScreen = false; // set to default value
});


/*******************************************************************************
 * Loading Screen Start
 ******************************************************************************/
/**
 * Handler for initializing loading screen.
 */
function initLoadingScreen() {
    showLoadingScreen();

    // any link with mailto href, do not show loading screen
    $("a[href^=mailto]").on("click",function() {
        skipLoadingScreen = true;
    });

    // any element with class disable-loading-screen, do not show loading screen
    $(".disable-loading-screen").on("click",function() {
        skipLoadingScreen = true;
    });
}

/**
 * Handler for showing the loading screen.
 */
function showLoadingScreen(delay) {
    if (delay === undefined || delay === "")
        $("#loadingScreenWrapper").fadeIn();
    else
        $("#loadingScreenWrapper").fadeIn(delay);
}

/**
 * Handler for hiding the loading screen.
 */
function hideLoadingScreen(delay) {
    if (delay === undefined || delay === "")
        $("#loadingScreenWrapper").fadeOut(1000);
    else
        $("#loadingScreenWrapper").fadeOut(delay);
}
/*******************************************************************************
 * Loading Screen End
 ******************************************************************************/


/*******************************************************************************
 * Common Navigation Start
 ******************************************************************************/
/**
 * Method that will redirect to home login.
 */
function redirectHomeLogin() {
    window.location = homeLoginPageUrl;
}

/**
 * Method that will redirect to eservice login.
 */
function redirectEserviceLogin() {
    window.location = eserviceLoginPageUrl;
}

/**
 * Method that will redirect the current page to a target url.
 * 
 * @param targetUrl
 */
function redirectToTargetUrl(targetUrl) {
    window.location = targetUrl;
}

/**
 * Method that will send a POST request with parameters to the server.
 * 
 * @param action
 * @param params
 */
function doPostRequest(action, params) {
    var form = $("<form/>", {method: "POST", action: action});
    if (params !== undefined) {
        // init params
        for (var key in params) {
            var hiddenField = $("<input/>", {type: "hidden", name: key, value: params[key]});
            form.append(hiddenField);
        }
    }
    // look for the first CSRF token instance and append it to our form
    var csrfTokenElmnt= $("input[name^='CSRFToken']:first");
    if (csrfTokenElmnt.length) {
        var csrfField = $("<input/>", {type: "hidden", name: csrfTokenElmnt.attr("name"), value: csrfTokenElmnt.val()});
        form.append(csrfField);
    } else {
        console.log("CSRF Token not found!");
    }
    // append form in document body
    $(document.body).append(form);
    form.submit();
}
/*******************************************************************************
 * Common Navigation End
 ******************************************************************************/


/*******************************************************************************
 * Custom Google Search Start
 ******************************************************************************/
/**
 * Method that will initialize the singpass custom google search.
 */
function initSearchForm() {

    if ($("#searchFormDiv").length) {
        $("[data-toggle=search-form]").on("mousedown", function (e) {
            e.preventDefault();
            if ($(".search-form-wrapper").hasClass("open")) {
                $("#searchIcon").removeClass("search-icon-hovered");
                $(".search-form-wrapper").removeClass("open");
                $("#searchtxt").val("");
            } else {
                $("#searchIcon").addClass("search-icon-hovered");
                $(".search-form-wrapper").addClass("open");
                $(".search-form-wrapper .search").focus();
            }
        });

        $(".search-form-wrapper .search").keypress(function (event) {
            if ($(this).val() == "Search") {
                $(this).val("");
            }
        });

        // search close is clicked
        $(".search-close").click(function (event) {
            $(".search-form-wrapper").removeClass("open");
            $("#searchtxt").val("");
        });

        // searchtxt focus
        $("#searchtxt").focus(function() {
            $("#searchIcon").addClass("search-icon-hovered");
        });

        // searchtxt focus out
        $("#searchtxt").focusout(function() {
            $("#searchIcon").removeClass("search-icon-hovered");
            $(".search-form-wrapper").removeClass("open");
            $(this).val("");
        });

        // prevent closing before custom search is triggered
        $("#searchFormSubmitBtn").on("mousedown", function(e) {
            e.preventDefault();
            searchCustomGoogleQuery();
        });
    }
}

/**
 * Handler when user press enter button upon searching.
 */
function doCustomGoogleSearch(e) {

    var keynum;
    if (window.event) { // IE
        keynum = e.keyCode;
    } else if (e.which) { // Netscape/Firefox/Opera
        keynum = e.which;
    }
    if (keynum == 13) {
        searchCustomGoogleQuery();
        return;
    }
    return;
}

/**
 * Handler for triggering custom google search.
 */
function searchCustomGoogleQuery() {

    $('button').removeAttr('disabled');
    var cx = '010781285529906403814:4ihl4o__8og';
    url = 'http://www.google.com/cse?cx=' + cx + '&q=' + $("#searchtxt").val();
    window.open(url);
    return false;
 }
/*******************************************************************************
 * Custom Google Search End
 ******************************************************************************/


/*******************************************************************************
 * Page Notification Start
 ******************************************************************************/
/**
 * Method that show the page error.
 * 
 * @param errorMsg the error message to show.
 * @param whether to append the message or replace the existing message.
 */
function showPageError(errorMsg, appendMsg) {
    if ($("#pageErrorNotificationWrapperdiv").length == 0) {
        var notificationMsg = $("<p/>", {id: "notificationMsg"}).html(errorMsg);
        var iconImgWrapper = $("<div/>", {class: "iconImg-wrapper"});
        iconImgWrapper.append($("<span/>", {class: "icon-img-error hidden-xs"}));
        iconImgWrapper.append($("<div/>", {class: "error-page-notification-msg"}).append(notificationMsg));
        var mainErrorDiv = $("<div/>", {id: "pageErrorNotificationWrapperdiv", class: "error-page-notification-wrapper"});
        mainErrorDiv.append(iconImgWrapper);
        mainErrorDiv.append($("<div/>", {class: "clearfix"}));
        $("#pageNotificationDiv").append(mainErrorDiv);
    } else {
        if (appendMsg) {
            $("#pageErrorNotificationWrapperdiv").find("#notificationMsg").append(errorMsg);
        } else {
            $("#pageErrorNotificationWrapperdiv").find("#notificationMsg").html(errorMsg);
        }
    }
}
/*******************************************************************************
 * Page Notification End
 ******************************************************************************/


/*******************************************************************************
 * Form Commmon Component Start
 ******************************************************************************/
/**
 * Method that will refresh the captcha image.
 * 
 * @param captchaElmnt the captcha html element id.
 */
function refreshCaptchaImg(captchaElmntId) {
    $("#" + captchaElmntId).attr("src", generateCaptchaUrl + "?rnd=" + Math.random());
}

/**
 * Method that will initialize the tooltip.
 */
function initializeTooltip() {
    $('.tooltip').tooltipster({
        animation: 'fade',
        delay: 200,
        theme: 'tooltipster-borderless',
        trigger: 'click',
        contentAsHTML: true,
        interactive: true
    });
}

/**
 * Method that will initialize the numeric input field.
 */
function initializeNumerInputField() {
    $(".numeric-input-field").on("keydown", function(e) {
        var charCode = e.keyCode ? e.keyCode : e.which ? e.which : e.charCode;
        if (charCode === 37 || charCode === 38 || charCode === 39 || charCode === 40 || charCode === 46 || e.ctrlKey) {
            return true; // for arrow keys, delete key and cntrl key
        } else if (e.shiftKey) {
            return false; // user pressed the shift key
        } else if (charCode <= 31 || (charCode >= 48 && charCode <= 57) || (charCode >= 96 && charCode <= 105)) {
            return true; // for numeric character and ascii char from 1 to 31
        } else {
            return false; 
        }
    });
}

/**
 * Method that will toggle nav bar in mobile view
 */
function intializeMobileNav() {
    if ($("#mySidenav").length) {
        $("[data-toggle=nav-toggle]").on("mousedown", function (e) {
            e.preventDefault();
            if ($("#mySidenav").width() == "250") {
                document.getElementById("mySidenav").style.width = "0";
            } else {
                document.getElementById("mySidenav").style.width = "250px";
            }
        });

        $(document).on('touchstart click', function(e) {
            if (!$(e.target).hasClass("fa-bars") && !$(e.target).hasClass("sidenav") && !$(e.target).parents("#mySidenav").length == 1) {
                document.getElementById("mySidenav").style.width = "0";
            }
        });
	}
}

/**
 * initialize password complexity
 * 
 * @param id
 *            the input field element id.
 */
function initializeCustomPasswordTag(id) {
    var previousCharCounterFlag = 0;
    var currentCharCounterFlag = 0;

    // required list
    var requiredTitle = $("<p>Required:</p>")
    var requiredOpt = $("<ul/>");
    requiredOpt.append($('<li/>', {id: 'password-length', class: 'pc-form-error'}).append($('<i/>', {class: 'icon-exclamation'})).append("8-24 characters"));
    requiredOpt.append($('<li/>', {id: 'password-alphabet', class: 'pc-form-error'}).append($('<i/>', {class: 'icon-exclamation'})).append("Alphabetic characters"));
    requiredOpt.append($('<li/>', {id: 'password-number', class: 'pc-form-error'}).append($('<i/>', {class: 'icon-exclamation'})).append("Numeric characters"));

    // optional list
    var optionalTitle = $("<p>Optional:</p>");
    var optionalOpt = $("<ul/>");
    optionalOpt.append($('<li/>', {id: 'password-special', class: 'pc-form-error'}).append($('<i/>', {class: 'icon-exclamation'})).append("Special character ($!#&@?%=_)"));

    // password complexity info div
    var passwordComplexityInfoDiv = $('<div/>', {class:'pwd-complexity-info pwd-complexity-hidden'});
    passwordComplexityInfoDiv.append(requiredTitle);
    passwordComplexityInfoDiv.append(requiredOpt);
    passwordComplexityInfoDiv.append(optionalTitle);
    passwordComplexityInfoDiv.append(optionalOpt);

    // password complexity max character error div
    var passwordComplexityMaxErrorDiv = $('<div/>', {class:'pwd-complexity-info pwd-complexity-hidden'});
    passwordComplexityMaxErrorDiv.append($("<ul/>").append($("<li/>", {class:'pc-form-error'}).append($('<i/>', {class: 'icon-exclamation'})).append("Maximum character reached")));

    // password complexity wrapper
    var passwordComplexityWrapper = $('<div/>', {class:'password-complexity-checker-wrapper'});
    passwordComplexityWrapper.append(passwordComplexityInfoDiv);
    passwordComplexityWrapper.append(passwordComplexityMaxErrorDiv);

    var mainDiv = $("#"+id).after(passwordComplexityWrapper);

    // Pop up animation
    var pswdValidationCriteria = {
        length: {
            $el: passwordComplexityInfoDiv.find('#password-length'),
            validate: function(value) {
                return value.length >= 8;
            }
        },
        alphabets: {
            $el: passwordComplexityInfoDiv.find('#password-alphabet'),
            validate: function(value) {
                return value.match(/[a-zA-Z]/);
            }
        },
        numeric: {
            $el: passwordComplexityInfoDiv.find('#password-number'),
            validate: function(value) {
                return value.match(/[\d]/);
            }
        },
        specialChars: {
            $el: passwordComplexityInfoDiv.find('#password-special'),
            validate: function(value) {
                return value.match(/[!@#$&%=_?]/);
            }
        }
    };

    $(mainDiv).keydown(function() {
        previousCharCounterFlag = $("#"+id).val().length;
    });

    $(mainDiv).keyup(function(e) {
        currentCharCounterFlag = $("#"+id).val().length;

        var pswdComplex = $(this).val();
        var valCriteria = null;
        var criteria = null;
        var isValid = true;

        if (e.which !== 9) {
            for (criteria in pswdValidationCriteria) {
                if (pswdValidationCriteria.hasOwnProperty(criteria)) {
                    valCriteria = pswdValidationCriteria[criteria];
                    if (valCriteria.validate(pswdComplex)) {
                        valCriteria.$el.removeClass('pc-form-error').addClass('pc-form-success');
                    } else {
                        valCriteria.$el.removeClass('pc-form-success').addClass('pc-form-error');
                        if (criteria != 'specialChars') {
                            isValid = false;
                        }
                    }
                }
            }

            if (isValid) {
                passwordComplexityInfoDiv.addClass('pwd-complexity-hidden');
                $(mainDiv).removeClass('password-error');

                if (previousCharCounterFlag === 24 && currentCharCounterFlag === 24) {
                    passwordComplexityMaxErrorDiv.removeClass('pwd-complexity-hidden');
                } else {
                    passwordComplexityMaxErrorDiv.addClass('pwd-complexity-hidden');
                }
            } else {
                passwordComplexityInfoDiv.removeClass('pwd-complexity-hidden');
                $(mainDiv).addClass('password-error');
            }
        }
    });

    $(mainDiv).on("focus", function(e) {
        e.preventDefault();
        passwordComplexityInfoDiv.removeClass('pwd-complexity-hidden');
    });

    $(mainDiv).on("blur", function(e) {
        e.preventDefault();
        passwordComplexityInfoDiv.addClass('pwd-complexity-hidden');
        passwordComplexityMaxErrorDiv.addClass('pwd-complexity-hidden');
    });
}
/*******************************************************************************
 * Form Commmon Component End
 ******************************************************************************/