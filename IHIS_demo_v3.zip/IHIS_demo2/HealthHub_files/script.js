/*************************************my health***********************/
function toggleChevron(e) {
    $(e.target)
		.prev('.panel-heading')
		.find("i.indicator")
		.toggleClass('fa fa-chevron-down fa fa-chevron-up');

}

$(document).ready(function () {
    $('.accordion').on('hidden.bs.collapse', toggleChevron);
    $('.accordion').on('shown.bs.collapse', toggleChevron);

    $('#accordion').on('hidden.bs.collapse', toggleChevron);
    $('#accordion').on('shown.bs.collapse', toggleChevron);

    $('#accordion1').on('hidden.bs.collapse', toggleChevron);
    $('#accordion1').on('shown.bs.collapse', toggleChevron);

    $('#accordions').on('hidden.bs.collapse', toggleChevron);
    $('#accordions').on('shown.bs.collapse', toggleChevron);

    $('#accordion_atoz').on('hidden.bs.collapse', toggleChevron);
    $('#accordion_atoz').on('shown.bs.collapse', toggleChevron);


    $('#accordion_browse_map').on('hidden.bs.collapse', toggleChevron);
    $('#accordion_browse_map').on('shown.bs.collapse', toggleChevron);

    //added by iyyappan for sitemap responsive
    $('.m-box-link').click(function () {
        $(this).toggleClass('active').closest('div').find('.box-holder').stop().slideToggle(350);
        return false;
    });
});

/*    
    $(function () {
    $('a[href="#search"]').on('click', function(event) {
        event.preventDefault();
        $('#search').addClass('open');
        $('#search > form > input[type="search"]').auto-focus();
    })
    
    $('#search, #search button.close').on('click keyup', function(event) {
        if (event.target == this || event.target.className == 'close' || event.keyCode == 27) {
            $(this).removeClass('open');
        }
    });
    
    
    //Do not include! This prevents the form from submitting for DEMO purposes only!
    $('form').submit(function(event) {
        event.preventDefault();
        return false;
    })
});*/


$(document).ready(function () {
    $(".menuclass").click(function () {

        if (window.innerWidth <= 900) {
            var tid = $(this).attr('attr-tab');

            if (tid == '1') {
                $(this).attr('href', '#home01');
            }
            if (tid == '2') {
                $(this).attr('href', '#menu02');
            }
            if (tid == '3') {
                $(this).attr('href', '#menu03');
            }
            $(".tab" + tid).click();
        } else {
            var tid = $(this).attr('attr-tab');
            $(".tab" + tid).click();
            $(".tab" + tid).parent('li').addClass('active');
        }
    });



    $('button#dropdownMenuButton').on('click', function () {
        $('div#bs-example-navbar-collapse-1').collapse('hide');
    });
});

/**************************programs**********************/


$(function () {
    if (!$.support.placeholder) {
        var active = document.activeElement;
        $(':text').focus(function () {
            if ($(this).attr('placeholder') != '' && $(this).val() == $(this).attr('placeholder')) {
                //$(this).val('').removeClass('hasPlaceholder');
            }
        }).blur(function () {
            if ($(this).attr('placeholder') != '' && ($(this).val() == '' || $(this).val() == $(this).attr('placeholder'))) {
                //$(this).val($(this).attr('placeholder')).addClass('hasPlaceholder');
            }
        });
        $(':text').blur();
        $(active).focus();
        $('form').submit(function () {
            $(this).find('.hasPlaceholder').each(function () {
                //$(this).val('');
            });
        });
    }
});


$(function () {
    // $.placeholder.shim();
});

$(document).ready(function () {
    var slickvar = $('#showslickscript').val();

    if (typeof slickvar == "undefined") { } else {

        $(".regular").slick({
            autoplay: true,
            dots: true,
            customPaging: function (slider, i) {
                var thumb = $(slider.$slides[i]).data();
                var j = i + 1;
                return '<a>' + j + '</a>';
            },


        });

        //custom function showing current slide
        var $status = $('.pagingInfo');
        var $slickElement = $('.slider');

        $('.share_img').on('click', function () {
            $(this).closest('.slick-slide').siblings().find('.click_div_share').css({ 'opacity': '0', 'height': '0' });
        });

        $slickElement.on('init reInit afterChange', function (event, slick, currentSlide, nextSlide) {
            //currentSlide is undefined on init -- set it to 0 in this case (currentSlide is 0 based)
            var i = (currentSlide ? currentSlide : 0) + 1;
            $status.text(i + '/' + slick.slideCount);
        });


        $('.nav_banner_text > ul > li > a').click(function (e) {
            e.preventDefault()
            $(".regular").slick("refresh");
            $(this).tab('show')
        });
    }

    $(".showtoggle").click(function () {
        var idd = $(this).attr('attr-id');
        $("." + idd + "div").toggle();
        $("." + idd + "right").toggle();
        $("." + idd + "down").toggle();
    });

    // venkat changes
    $('.share_img').on('click', function () {
        $(this).closest('.slick-slide').siblings().find('.click_div_share').css({ 'opacity': '0', 'height': '0' });
        $(this).closest('.col-lg-3').siblings().find('.click_div_share').css({ 'opacity': '0', 'height': '0' });
        //programmes
        $(this).closest('.full_screen').siblings().find('.click_div_share').css({ 'opacity': '0', 'height': '0' });
        $(this).closest('.col-xs-12').siblings().find('.click_div_share').css({ 'opacity': '0', 'height': '0' });
        // live healthy
        $(this).closest('.full_screen_live').siblings().find('.click_div_share').css({ 'opacity': '0', 'height': '0' });
    });

    $('.share_img').on('click', function () {
        var parent = $(this).parent();
        var id = parent.children('.showtoggle').attr('attr-id');
        if ($("." + id + "div").is(':visible')) {
            $("." + id + "div").toggle();
            $("." + id + "right").toggle();
            $("." + id + "down").toggle();
        }
    });
    var $elements = $('.share_img, .click_div_share');
    $('.share_img').click(function () {
        $elements.eq($elements.index(this) + 1).css({
            "opacity": "1",
            "height": "auto",
            "z-index": "9999",
            "top": "0"
        });
        $elements.eq($elements.index(this) + 1).focus();
    });
    var $elements = $('.share_img, .click_div_share');
    $('.slider_right').find('.share_img').click(function () {
        var h1 = $('.slick-slide').height();
        var h2 = $('.img_silder_left').height();

        var topgap = "-" + h2;

        if (window.innerWidth <= 991) {
            $elements.eq($elements.index(this) + 1).css({
                "opacity": "1",
                "z-index": "9999",
                "top": topgap,
                "margin": "0"
            }).height(h1);
            $elements.eq($elements.index(this) + 1).focus();
        } else {
            $elements.eq($elements.index(this) + 1).css({
                "opacity": "1",
                "z-index": "9999",
                "top": "0",
                "margin": "0",
                "height": "100%"
            });
            $elements.eq($elements.index(this) + 1).focus();
        }


    });
    var $elements = $('.share_img, .click_div_share');
    $('.live_slider_right').find('.share_img').click(function () {
        //var h1 = $('.slick-slide').height();
        var h1 = $('.slick-list').height();
        var h2 = $('.img_silder_live').height();

        var topgap = "-" + h2;

        if (window.innerWidth <= 991) {
            $elements.eq($elements.index(this) + 1).css({
                "opacity": "1",
                "z-index": "9999",
                "top": topgap,
                "margin": "0"
            }).height(h1);
            $elements.eq($elements.index(this) + 1).focus();
        } else {
            $elements.eq($elements.index(this) + 1).css({
                "opacity": "1",
                "z-index": "9999",
                "top": "0",
                "margin": "0",
                "height": "100%",
                "padding": "0"
            });
            $elements.eq($elements.index(this) + 1).focus();
        }


    });


    $('.close').on('click', function () {
        $(this).parent().css({
            'opacity': '0',
            'height': '0'
        });
    });


    $('.all_shows').click(function () {
        $('#allanchor').click();
    });

    /*$('.dropdown-menu').click(function(e){e.preventDefault();});*/
    // Select all links with hashes
    $('a[href*="#all"]')
        // Remove links that don't actually link to anything
        .not('[href="#"]')
        .not('[href="#0"]')
        .click(function (event) {
            // On-page links
            if (
                location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') &&
                location.hostname == this.hostname
            ) {

                var target = $(this.hash);
                target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
                // Does a scroll target exist?
                if (target.length) {
                    // Only prevent default if animation is actually gonna happen
                    event.preventDefault();
                    $('html, body').animate({
                        scrollTop: target.offset().top
                    }, 1000, function () {

                        var $target = $(target);
                        //$target.focus();
                        if ($target.is(":focus")) { // Checking if the target was focused
                            //return false;
                        } else {

                        };
                    });
                }
            }
        });


    //Anchor Link
    $(document).ready(function () {
        if (location.href.indexOf('/programmes') >= 0) {
            var anchorLink = $('#allanchor');
            var hash = $(location).attr('hash');

            if (anchorLink != undefined && anchorLink.attr('href') == hash) {
                anchorLink.click();
            }
        }
    });

    /************************************shotwellhealthy********************************/


    $(".search_button").on('click', function () {

        $("#searchclass").show();

    });

    $(".screen-reader-text").on('click', function () {

        $("#searchclass").hide();


    });


    $(".search_buttons").on('click', function () {


        $("#searchclass_div").show();


    });

    $(".screen-reader").on('click', function () {


        $("#searchclass_div").hide();


    });

    $('[placeholder]').focus(function () {
        var input = $(this);
        if (input.val() == input.attr('placeholder')) {
            input.val('');
            input.removeClass('placeholder');
        }
    }).blur(function () {
        var input = $(this);
        if (input.val() == '' || input.val() == input.attr('placeholder')) {
            input.addClass('placeholder');
            //input.val(input.attr('placeholder'));
        }
    }).blur();


    $('.unevens').slick({
        dots: true,
        infinite: false,
        speed: 300,
        slidesToShow: 3,
        slidesToScroll: 3,
        responsive: [{
            breakpoint: 1199,
            settings: {
                slidesToShow: 3,
                slidesToScroll: 3,
                infinite: true,
                dots: true
            }
        },
            {
                breakpoint: 901,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2
                }
            },
            {
                breakpoint: 601,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
        ]
    });

    if (typeof slickvar == "undefined") { } else {
        $('.nav_banner_text > ul > li > a').click(function (e) {
            e.preventDefault()
            $(".regular").slick("refresh");
            $(this).tab('show')
        })


        $('.uneven').slick({
            dots: true,
            infinite: false,
            speed: 300,
            slidesToShow: 4,
            slidesToScroll: 4,
            responsive: [{
                breakpoint: 1199,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 3,
                    infinite: true,
                    dots: true
                }
            },
                {
                    breakpoint: 600,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 2
                    }
                },
                {
                    breakpoint: 480,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1
                    }
                }
            ]
        });
    }


    /*show details index*/
    var showhide = 1;
    $('.index_details_show li').on('click', function () {
        showhide = 2;
        $('.mobile_pop').show();
        if (window.innerWidth <= 600) {
            if (showhide == 2) {
                $("body").css({
                    "overflow": "hidden"
                });
            } else {
                $("body").css({
                    "overflow": "visible"
                });
            }

        } else {
            $("body").css({
                "overflow": "visible"
            });
        }

    });
    $('.mobile_pop .close_btn').on('click', function () {
        showhide = 3;
        if (showhide == 2) {
            $("body").css({
                "overflow": "hidden"
            });
        } else {
            $("body").css({
                "overflow": "visible"
            });
        }
        $('.mobile_pop').hide();

    });


    /*show details index*/
    var showhide1 = 1;
    $('.accordion_browse').on('click', function () {

        showhide1 = 2;
        //$('.mobile_pop_map').show();
        if (window.innerWidth <= 600) {
            if (showhide1 == 2) {
                $("body").css({
                    "overflow": "hidden"
                });
            } else {
                $("body").css({
                    "overflow": "auto"
                });
            }

        } else {
            $("body").css({
                "overflow": "auto"
            });
        }

    });

    $('.mobile_pop_map .close_btn').on('click', function () {
        showhide1 = 3;
        if (showhide1 == 2) {
            $("body").css({
                "overflow": "auto"
            });
        } else {
            $("body").css({
                "overflow": "auto"
            });
        }
        $('.mobile_pop_map').hide();
    });


    //$('.arrow_index').before().click(function () {
    //    $("html, body").animate({
    //        scrollTop: 0
    //    }, "slow");
    //    return false;
    //});

    $('.close').on('click', function () {
        var attr_cls = $(this).attr('attr-cls');
        $('.' + attr_cls).click()
    });


    $('.indicator').on('click', function () {
        var myClass = $(this).attr("class");
        if (myClass.indexOf("fa-chevron-down") > -1) {
            $(this).parent().parent().parent().addClass('newclassadded');
        } else {
            $(this).parent().parent().parent().removeClass('newclassadded');
        }
    });
});

$(document).ready(function () {
    var showtable = $('#showtable').val();
    if (typeof showtable == "undefined") { } else {
        $('table.display').DataTable({
            language: {
                paginate: {
                    next: '>', // or '→'
                    previous: '<' // or '←' 
                }
            }
        });
    }

});


/*********************************************atozhealth***********************************/

$(document).ready(function () {
    $('.slide_arr').on('click', function () {
        var class_name = $(this).attr('attr-txt');
        $('.slick-' + class_name).click();
    });


    $("#small").click(function (event) {
        event.preventDefault();
        $("h1").animate({ "font-size": "24px" });
        $("h2").animate({ "font-size": "16px" });
        $(".resize_text div:not(.caption-text, .caption-text p), .resize_text ul li:not(.caption-text, .caption-text p), .resize_text p:not(.caption-text, .caption-text p)").animate({
            "font-size": "12px"
        });
        $(".caption-text, .caption-text p").animate({
            "font-size": "10px"
        });

    });

    $("#medium").click(function (event) {
        event.preventDefault();
        $("h1").animate({ "font-size": "36px" });
        $("h2").animate({ "font-size": "24px" });
        $(".resize_text div:not(.caption-text, .caption-text p), .resize_text ul li:not(.caption-text, .caption-text p), .resize_text p:not(.caption-text, .caption-text p)").animate({
            "font-size": "16px"
        });
        $(".caption-text, .caption-text p").animate({
            "font-size": "12px"
        });

    });

    $("#large").click(function (event) {
        event.preventDefault();
        $("h1").animate({ "font-size": "48px" });
        $("h2").animate({ "font-size": "30px" });
        $(".resize_text div:not(.caption-text, .caption-text p), .resize_text ul li:not(.caption-text, .caption-text p), .resize_text p:not(.caption-text, .caption-text p)").animate({
            "font-size": "20px"
        });
        $(".caption-text, .caption-text p").animate({
            "font-size": "14px"
        });

    });

    $(".content_atoz_text a").click(function () {
        $(".content_atoz_text a").removeClass("selected");
        $(this).addClass("selected");

    });


    if (window.innerWidth <= 900) {
        adjustAccordions();
    }
});


function adjustAccordions() {

    var accordions = $('#accordion .panel-collapse.collapse');
    var indicator = $('.indicator');
    accordions.slice(1, accordions.length).each(function () {
        $(this).removeClass('in');
    });
    indicator.slice(1, accordions.length).each(function () {
        if ($(this).hasClass('fa-chevron-up')) {
            $(this).removeClass('fa-chevron-up');
            $(this).addClass('fa-chevron-down');
        }
    });

}

if (window) {
    var cachedWidth = $(window).width();
    window.addEventListener('resize', function () {
        var newWidth = $(window).width();

        if (newWidth !== cachedWidth && window.innerWidth <= 900) {
            adjustAccordions();
        }
    })
}

$(document).ready(function () {
    $(".dropdowns dt a").on('click', function () {
        $(".dropdowns dd ul").slideToggle('fast');
    });

    $(".dropdowns dd ul li a").on('click', function () {
        $(".dropdowns dd ul").hide();
    });
});

function getSelectedValue(id) {
    return $("#" + id).find("dt a div.value").html();
}

$(document).ready(function () {
    $(document).bind('click', function (e) {
        var $clicked = $(e.target);
        if (!$clicked.parents().hasClass("dropdowns")) $(".dropdowns dd ul").hide();
    });

    $('.mutliSelect input[type="checkbox"]').on('click', function () {

        var title = $(this).closest('.mutliSelect').find('input[type="checkbox"]').val(),
            title = $(this).val() + ",";

        if ($(this).is(':checked')) {
            var i = 0;
            var count;

            $(".filter_che").each(function (index) {
                if ($(this).is(':checked')) {
                    i = i + 1;
                    count = i;
                }
            });

            if (count == undefined) {
                //$('.txt_filter').html('Filter these listings');
                //$('.txt_filters').html('Filter these listings');
            } else if (count == 1) {
                $('.txt_filter').html("You’ve applied <span class='counts_filters'>" + count + "</span> filter");
                $('.txt_filters').html("You’ve applied " + count + " filter")
            } else {
                $('.txt_filter').html("You’ve applied <span class='counts_filters'>" + count + "</span> filters");
                $('.txt_filters').html("You’ve applied " + count + " filters");
            }
        } else {
            var i = 0;
            var count;

            $(".filter_che").each(function (index) {
                if ($(this).is(':checked')) {
                    i = i + 1;
                    count = i;
                }
            });

            if (count == undefined) {
                //$('.txt_filter').html('Filter these listings');
                //$('.txt_filters').html('Filter these listings');
            } else if (count == 1) {
                $('.txt_filter').html("You’ve applied <span class='counts_filters'>" + count + "</span> filter");
                $('.txt_filters').html("You’ve applied " + count + " filter");
            } else {
                $('.txt_filter').html("You’ve applied <span class='counts_filters'>" + count + "</span> filters");
                $('.txt_filters').html("You’ve applied " + count + " filters");
            }
        }
    });
});