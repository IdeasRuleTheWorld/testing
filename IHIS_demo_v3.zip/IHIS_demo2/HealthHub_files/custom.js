function profileCall() {
    $('.overlay-section').toggle();
    $('.profilebox').toggle();
    $('.overlay-section.fpwd').hide();
    $(".profilebox").css('top', '35px');
}

//start - master page searc hbutton
function MasterTopSearchclick(e) {
    var code = e.keyCode ? e.keyCode : e.which;
    if (code === 13) {
        //event.preventDefault ? event.preventDefault() : event.returnValue = false;
        $('#MasterbtnSubmit').click();
    }
}

function MasterTopSearchBtnClick() {

    var TextVal = document.getElementById('MasterTopsearchBox').value;
    if (TextVal.length > 0) {
        var url = "/search?q=" + TextVal
        location.href = url;
    }
}

//function MobileRedirectToSearch() {

//    var TextVal = document.getElementById('searchBoxMobile').value;
//    if (TextVal.length > 0) {
//        var url = "/search?q=" + TextVal
//        location.href = url;
//    }
//}
function MobileRedirectToSearch() {
    var querytext = document.getElementById('MasterTopsearchBoxMobile').value;
    querytext = querytext.trim();
    querytext = encodeURIComponent(encodeURIComponent(querytext));

    if (querytext != null && querytext != '' && querytext.length > 0) {
        var url = "/search?k=" + querytext;
        location.href = url;
    }
}

function PortalRedirectToSearch() {
    var querytext = document.getElementById('MasterTopsearchBoxPortal').value;
    querytext = querytext.trim();
    querytext = encodeURIComponent(encodeURIComponent(querytext));

    if (querytext != null && querytext != '' && querytext.length > 0) {
        var url = "/search?k=" + querytext;
        location.href = url;
    }
}

$(document).click(function (e) {
    if ($('.top-links > li > span > div > a.btn-log').hasClass('active') && $(e.target).closest('.account-area').get(0) == null) {
        $('.top-links > li > span > div > a.btn-log').removeClass('active');
        $('.overlay-section').hide();
        $('#account-box').hide();
        $('.profilebox').hide();
    }

    $("#MasterTopsearchBoxPortal").keydown(function (e) {
        if (e.keyCode == 13) {
            e.preventDefault();
            PortalRedirectToSearch();
        }
    });

    //$("#btnMasterTopsearchBox").click(function (e) {
    //    RedirectToSearch();
    //});

    $("#MasterTopsearchBoxMobile").keydown(function (e) {
        if (e.keyCode == 13) {
            e.preventDefault();
            MobileRedirectToSearch();
        }
    });

    //$("#btnMasterTopsearchBoxMobile").click(function (e) {
    //    MobileRedirectToSearch();
    //});
});

//Clear Profile Local Storage
function ClearMyProfileLocalStorage() {
    sessionStorage.removeItem("hhprofile");
    //console.log("hhprofile is cleared from sessionStorage...");
}

function isLocalStorageNameSupported() {
    var testKey = 'test', storage = window.sessionStorage;
    try {
        storage.setItem(testKey, '1');
        storage.removeItem(testKey);
        return localStorageName in win && win[localStorageName];
    }
    catch (error) {
        return false;
    }
}

//Clear Profile Local Storage
function ClearMyProfileLocalStorage() {
    sessionStorage.removeItem("hhprofile");
    //console.log("hhprofile is cleared from sessionStorage...");
}


function callShare(id) {

}

//general functions - can be used to read and create cookies
// <--
function readCookie(name) {
    var nameEQ = name + "=",
        ca = document.cookie.split(';'),
        i, c;

    for (i = 0; i < ca.length; i++) {
        c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1, c.length);
        }

        if (c.indexOf(nameEQ) == 0) {
            return c.substring(nameEQ.length, c.length);
        }
    }
    return null;
}

function createCookie(name, value, days) {
    var date, expires;

    if (days) {
        date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        expires = "; expires=" + date.toGMTString();
    } else {
        expires = "";
    }
    document.cookie = name + "=" + value + expires + "; path=/";
}

//-->

//<-- used to set cookie in directory
function showDirectoryCategory() {
    var appendParam = "";
    if (window.matchMedia('(max-width: 900px)').matches) {
        appendParam = "?sc=1";
    }

    var curTab = readCookie("dirCategory");
    if (curTab === 'undefined' || curTab === null) {
        window.location.href = window.location.protocol + "//" + window.location.host + '/directory/blood-banks' + appendParam;
    }
    else {
        window.location.href = window.location.protocol + "//" + window.location.host + '/directory/' + curTab + appendParam;
    }
}
//-->

function gotoAZCategoriestab() {
    window.location.href = window.location.protocol + "//" + window.location.host + '/a-z';
}

function gotoAZIndextab() {
    window.location.href = window.location.protocol + "//" + window.location.host + '/a-z/a';
}

function gotoAZMedicationstab() {
    window.location.href = window.location.protocol + "//" + window.location.host + '/a-z/a?cat=medications';
}

function atozdetCont(id, el) {

    $(".content_atoz_left_side1 li").removeClass("active");
    $(".content_atoz_left_side1 li:nth-child(" + id + ")").addClass("active");
    $(".collapse").removeClass("in");
    $(".accordion-toggle").addClass("collapsed");

    $("#collapse" + id).addClass("in");
    $(".first" + id + " .accordion-toggle").removeClass("collapsed");
    $('.panel-collapse').removeAttr('style');
}

//Print function for all detail page
function printDiv(divID) {
    window.print();
}


$(document).ready(function () {
    var str = "";
    var i = 1;

    $(".atoz_p.atoz-details h2").each(function (index) {
        if ($(this).text().trim() == '') {
            $(this).remove();
        }
        $(this).find('br').remove();
    });

    $('.atoz_p.atoz-details h2').each(function (index) {

        if ($(this).html().trim() != '') {
            var textToShow = $(this).html().replace(/&nbsp;|&#8203;/g, ' ');
            if (index == '0') {
                str += '<li class="active filter" onclick=atozdetCont("' + i + '",this)><a href="#' + i + '">' + textToShow + '</a></li>';
            } else {
                str += '<li class="filter" onclick=atozdetCont("' + i + '",this)><a href="#' + i + '">' + textToShow + '</a></li>';
            }
            i++;
        }
    });
    $('.content_atoz_left_side1').html(str);

    $(".atoz_p.atoz-details h2").each(function (index) {
        $(this).nextUntil("h2").andSelf().wrapAll('<div class="panel panel-default">');
    });
    $(".atoz_p.atoz-details .panel").wrapAll('<div class="panel-group" id="accordion_atoz">');

    var $elements = $(".atoz_p.atoz-details .panel-group h2");
    $elements.each(function (index) {
        $(this).replaceWith('<div class="panel-heading"><h4 class="panel-title"><a id="' + (index + 1) + '" class="accordion-toggle appointment in" data-toggle="collapse" data-parent="#accordion" data-target="#collapse' + (index + 1) + '">' + $(this).text() + ' <i class="indicator fa fa-chevron-up pull-right" aria-hidden="true "></i> </a></h4></div>');
    });

    $(".atoz_p.atoz-details .panel-group .panel-heading").each(function (index) {
        $(this).nextUntil("h2").wrapAll('<div id="collapse' + (index + 1) + '" class="panel-collapse collapse in"><div class="panel-body" >');
    });
    $('#accordion_atoz').on('hidden.bs.collapse', toggleChevron);
    $('#accordion_atoz').on('shown.bs.collapse', toggleChevron);


    //Detail page table responsive.
    $(".info-area.info-box-holder table").wrap("<div class='table-responsivea'></div>");
    $(".info-area.info-box-holder table").addClass('table');
    $(".info-area.info-box-holder table").css({ "overflow-x": "scroll", "display": "block", "border": "none" });
    $(".info-area.info-box-holder table td").css("display", "table-cell");

    //dotdotdot
    $('.slider_right .padding-0 p, .full_screen .box_tab .text_prog p, .box_tab p, .tab_mobile_tab .app_ment a, .tab_mobile_tab .app_ment span.des').dotdotdot(); //For Programs
    $('.live_slider_right .live_share-icon p, .text_popular p').dotdotdot(); //For Live Healthy
    $('.health-statis-sec .text_prog h5').dotdotdot(); //For A-Z
    $(".live_healthy_panel .panel-heading .app_ment .des, .detail_wts_events span:nth-child(2), .detail_wts_events span.kickbox").dotdotdot(); //For Events
    //$(".map_loction .panel h4.panel-title a span.app_ment span").dotdotdot(); //For directory
    $(".healthsservices_box_li p, .healthsservices_box p").dotdotdot(); // for home page

    //Close other carousel share div
    $('ul.slick-dots li, .slick-prev, .slick-next').on('click', function () {
        $('.slick-slide .close').parent().css({
            'opacity': '0',
            'height': '0'
        });
    });

    //Back to Top
    $('.btn-back-to-top').click(function () {
        $('html, body').stop().animate({
            scrollTop: 0
        }, 450);
        return false;
    });
    $(window).scroll(function () {
        if ($(this).scrollTop() != 0) {
            $('.btn-back-to-top').fadeIn(450);
        }
        else {
            $('.btn-back-to-top').fadeOut(450);
        }
    });

    //Change password Popoup    
    $('.change-pass a').click(function () {
        var href_ = $(this).attr('href');
        if ($(href_).length) {
            $('.overlay-section.fpwd').show();
            $('body').addClass('fixed');
            $(href_).stop().animate({
                top: '150px'
            }, 500);
        }
        return false;
    });
    $('.popup-holder .btn-cancel').click(function () {
        $('.overlay-section.fpwd').hide();
        $('body').removeClass('fixed');
        $(this).closest('.overlay-holder').stop().animate({
            top: '-600px'
        }, 1500);
        return false;
    });

    //A-Z detail page line hiding for responsive
    if ($.trim($('.rel-imu').text()) === "") {
        $('.rel-lin').hide();
    }

    if ($.trim($('section.content_live_healthy .join_box').text()) === "") {
        $('.content_atoz.content_livehealthy').css('box-shadow', 'none');
    }

    $('.gallery-content p').each(function () {
        var $this = $(this);
        if ($this.html().replace(/\s|&nbsp;/g, '').length == 0)
            $this.remove();
    });
});


